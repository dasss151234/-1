-- GodPause --

nameplate.ALL:setText("§6The Pequod Captain")
nameplate.Entity:setVisible(false)


-- Model Set --
vanilla_model.PLAYER:setVisible(false)
vanilla_model.ARMOR:setVisible(false)
animations.model.blinking:play()
models.model.Player.UpperBody.MHead.eyes.er:setSecondaryRenderType("Eyes")
models.model.Player.UpperBody.MHead.eyes.el:setSecondaryRenderType("Eyes")
models.model.Player.UpperBody.RightArm.MRA.harpoon.hpglow:setSecondaryRenderType("Eyes")
models.model.Player.UpperBody.RightArm.MRA.harpoon.effect1:setSecondaryRenderType("Eyes")
models.model.Player.UpperBody.RightArm.MRA.harpoon.effect2:setSecondaryRenderType("Eyes")
models.model.Trident.tdglow:setSecondaryRenderType("Eyes")
models.model.Player.UpperBody.LeftArm.gasharpoon.ghp2.ghpglow:setSecondaryRenderType("Eyes")
models.model.Player.UpperBody.MHead.pipe:setSecondaryRenderType("Eyes")
models.model.Camera.skill1.coinskill1:setPrimaryRenderType("EMISSIVE_SOLID")
models.model.Camera.skill1.coinskill2:setPrimaryRenderType("EMISSIVE_SOLID")
models.model.Camera.skill2.coinskill3:setPrimaryRenderType("EMISSIVE_SOLID")
models.model.Camera.skill2.coinskill4:setPrimaryRenderType("EMISSIVE_SOLID")
models.model.Camera.skill2.coinskill5:setPrimaryRenderType("EMISSIVE_SOLID")
models.model.Camera.skill3.coinskill6:setPrimaryRenderType("EMISSIVE_SOLID")
models.model.Camera.skill3.coinskill7:setPrimaryRenderType("EMISSIVE_SOLID")
models.model.Camera.skill3.coinskill8:setPrimaryRenderType("EMISSIVE_SOLID")
models.model.Camera.skill3.coinskill9:setPrimaryRenderType("EMISSIVE_SOLID")


-- Squapi Movement --

local squapi = require("SquAPI")
squapi.smoothHead(models.model.Player.UpperBody.MHead, 0.5, 0.4, true)
squapi.smoothTorso(models.model.Player.UpperBody, 0.35, 0.2, true)
squapi.eye(models.model.Player.UpperBody.MHead.eyes.el,0.1,0.9,0.2,0.3,nil)
squapi.eye(models.model.Player.UpperBody.MHead.eyes.er,0.9,0.1,0.2,0.3,nil)


-- Swinging Physics --

local SwingingPhysics = require("swinging_physics")
local swingOnBody = SwingingPhysics.swingOnBody
swingOnBody(models.model.Player.UpperBody.Body.Skirt, 90, {-30,10,-90,90,-10,10})



-- Action Wheel --

local mainPage = action_wheel:newPage()
local skillPage = action_wheel:newPage()
action_wheel:setPage(mainPage)


-- Skill Page --

function pings.skill1()
     animations.model.skill1:play()
     animations.model.skill2:stop()
     animations.model.skill3:stop()
     animations.model.onweapon:stop()
     animations.model.walkonweapon:stop()
     animations.model.slept:stop()
     models.model.Player.UpperBody.RightArm.MRA.harpoon:setVisible(true)
     models.model.Player.UpperBody.RightArm.MRA.harpoon.effect1:setVisible(true)
     models.model.Player.UpperBody.RightArm.MRA.harpoon.effect2:setVisible(true)
     models.model.Camera.skill1:setVisible(true)
     models.model.Camera.skill2:setVisible(false)
     models.model.Camera.skill3:setVisible(false)
end

local skill1 = skillPage:newAction()
    :setColor(0.89,0.31,1)
    :title("To Me!")
    :setTexture(textures["skill1"])
    :onLeftClick(pings.skill1)


function pings.skill2()
     animations.model.skill1:stop()
     animations.model.skill2:play()
     animations.model.skill3:stop()
     animations.model.onweapon:stop()
     animations.model.walkonweapon:stop()
     animations.model.slept:stop()
     models.model.Player.UpperBody.RightArm.MRA.harpoon:setVisible(true)
     models.model.Player.UpperBody.RightArm.MRA.harpoon.effect1:setVisible(true)
     models.model.Player.UpperBody.RightArm.MRA.harpoon.effect2:setVisible(true)
     models.model.Camera.skill1:setVisible(false)
     models.model.Camera.skill2:setVisible(true)
     models.model.Camera.skill3:setVisible(false)
end

local skill2 = skillPage:newAction()
    :setColor(0.38,0.65,1)
    :title("Pursue Them to the End")
    :setTexture(textures["skill2"])
    :onLeftClick(pings.skill2)



function pings.skill3()
     animations.model.skill1:stop()
     animations.model.skill2:stop()
     animations.model.skill3:play()
     animations.model.onweapon:stop()
     animations.model.walkonweapon:stop()
     animations.model.slept:stop()
     models.model.Player.UpperBody.RightArm.MRA.harpoon:setVisible(true)
     models.model.Player.UpperBody.RightArm.MRA.harpoon.effect1:setVisible(true)
     models.model.Player.UpperBody.RightArm.MRA.harpoon.effect2:setVisible(true)
     models.model.Camera.skill1:setVisible(false)
     models.model.Camera.skill2:setVisible(false)
     models.model.Camera.skill3:setVisible(true)
end


local skill3 = skillPage:newAction()
    :setColor(1,0.38,0.38)
    :title("Harpoon of Obsesssion")
    :setTexture(textures["skill3"])
    :onLeftClick(pings.skill3)



-- Main Page --

function pings.wakeslept(state)
  if state then 
     animations.model.slept:play()
     animations.model.blinking:stop()
  else 
     animations.model.slept:stop()
     animations.model.wake:play()
     animations.model.blinking:play()
  end
end

local wakesleptblinking = mainPage:newAction()
     :setColor(1,0.6,0)
     :title("Eyes Open - Close")
     :item("ender_pearl")
     :toggleItem("ender_eye")
     :hoverColor(1,0,1)
     :setOnToggle(pings.wakeslept)



-- Invisible Weapon for Harpoon --

function events.item_render(item, mode)
    if item.id == "minecraft:trident" then
       return models.model.ItemInvisible
    end
end

function events.item_render(item, mode)
    if item.id == "minecraft:bow" then
       return models.model.Itemgasharpoon
    end
end

function events.item_render(item, mode)
    if item.id == "minecraft:shield" then
       return models.model.Itemshield
    end
end



-- Some Event Script --

function events.tick()
	if (player:getItem(1).id == "minecraft:trident") and animations.model.skill1:isStopped() and animations.model.skill2:isStopped() and animations.model.skill3:isStopped() and animations.model.walkonweapon:isStopped() then
                action_wheel:setPage(skillPage)
                animations.model.onweapon:play()
                animations.model.slept:stop()
                animations.model.trident:stop()
		models.model.ItemInvisible:setVisible(true)
		models.model.Itemshield:setVisible(true)
		models.model.Player.UpperBody.RightArm.MRA.harpoon:setVisible(true)
                models.model.Player.UpperBody.RightArm.MRA.harpoon.effect1:setVisible(false)
                models.model.Player.UpperBody.RightArm.MRA.harpoon.effect2:setVisible(false)
                models.model.Camera.skill1:setVisible(false)
                models.model.Camera.skill2:setVisible(false)
                models.model.Camera.skill3:setVisible(false)
	end
	if player:getVelocity().xz:length() > .01 and models.model.Player.UpperBody.RightArm.MRA.harpoon:getVisible() then
                animations.model.walkonweapon:play()
                animations.model.onweapon:stop()
                animations.model.skill1:stop()
                animations.model.skill2:stop()
                animations.model.skill3:stop()
                animations.model.slept:stop()
                animations.model.trident:stop()
		models.model.ItemInvisible:setVisible(true)
		models.model.Itemshield:setVisible(true)
		models.model.Player.UpperBody.RightArm.MRA.harpoon:setVisible(true)
                models.model.Player.UpperBody.RightArm.MRA.harpoon.effect1:setVisible(false)
                models.model.Player.UpperBody.RightArm.MRA.harpoon.effect2:setVisible(false)
                models.model.Camera.skill1:setVisible(false)
                models.model.Camera.skill2:setVisible(false)
                models.model.Camera.skill3:setVisible(false)
	end
        if player:getSwingArm() then
                animations.model.walkonweapon:stop()
                animations.model.onweapon:stop()
                animations.model.skill1:stop()
                animations.model.skill2:stop()
                animations.model.skill3:stop()
                models.model.Camera.skill1:setVisible(false)
                models.model.Camera.skill2:setVisible(false)
                models.model.Camera.skill3:setVisible(false)
                models.model.Player.UpperBody.RightArm.MRA.harpoon.effect1:setVisible(false)
                models.model.Player.UpperBody.RightArm.MRA.harpoon.effect2:setVisible(false)
	end
	if player:getPose() == "CROUCHING" then
                animations.model.walkonweapon:stop()
                animations.model.onweapon:stop()
                animations.model.skill1:stop()
                animations.model.skill2:stop()
                animations.model.skill3:stop()
                models.model.Camera.skill1:setVisible(false)
                models.model.Camera.skill2:setVisible(false)
                models.model.Camera.skill3:setVisible(false)
                models.model.Camera.skillarrow:setVisible(false)
                models.model.Player.UpperBody.RightArm.MRA.harpoon.effect1:setVisible(false)
                models.model.Player.UpperBody.RightArm.MRA.harpoon.effect2:setVisible(false)
	end
	if (player:getItem(1).id == "minecraft:air") or not (player:getItem(1).id == "minecraft:trident") then
                action_wheel:setPage(mainPage)
                animations.model.walkonweapon:stop()
                animations.model.onweapon:stop()
                animations.model.skill1:stop()
                animations.model.skill2:stop()
                animations.model.skill3:stop()
                animations.model.trident:stop()
		models.model.ItemInvisible:setVisible(false)
		models.model.Player.UpperBody.RightArm.MRA.harpoon:setVisible(false)
                models.model.Player.UpperBody.RightArm.MRA.harpoon.effect1:setVisible(false)
                models.model.Player.UpperBody.RightArm.MRA.harpoon.effect2:setVisible(false)
                models.model.Camera.skill1:setVisible(false)
                models.model.Camera.skill2:setVisible(false)
                models.model.Camera.skill3:setVisible(false)
	end
	if (player:getItem(2).id == "minecraft:trident") and not (player:getItem(1).id == "minecraft:trident") then
                animations.model.walkonweapon:stop()
                animations.model.onweapon:stop()
                animations.model.skill1:stop()
                animations.model.skill2:stop()
                animations.model.skill3:stop()
                action_wheel:setPage(mainPage)
		models.model.ItemInvisible:setVisible(false)
                models.model.Player.UpperBody.RightArm.MRA.harpoon.effect1:setVisible(false)
                models.model.Player.UpperBody.RightArm.MRA.harpoon.effect2:setVisible(false)
	end
	if (player:getItem(1).id == "minecraft:trident") and player:isUsingItem() then
                animations.model.trident:play()
                animations.model.walkonweapon:stop()
                animations.model.onweapon:stop()
                animations.model.skill1:stop()
                animations.model.skill2:stop()
                animations.model.skill3:stop()
                models.model.Player.UpperBody.RightArm.MRA.harpoon.effect1:setVisible(false)
                models.model.Player.UpperBody.RightArm.MRA.harpoon.effect2:setVisible(false)
        end
	if (player:getItem(1).id == "minecraft:trident") and not player:isUsingItem() then
                animations.model.trident:stop()
	end
        if (player:getItem(2).id == "minecraft:bow") then
		models.model.Itemgasharpoon:setVisible(true)
		models.model.Player.UpperBody.LeftArm.gasharpoon:setVisible(true)
                animations.model.onarrow:play()
        end
	if (player:getItem(2).id == "minecraft:air") or not (player:getItem(2).id == "minecraft:bow") then
		models.model.Itemgasharpoon:setVisible(false)
		models.model.Player.UpperBody.LeftArm.gasharpoon:setVisible(false)
		models.model.Player.UpperBody.LeftArm.MLA:setVisible(true)
                models.model.Camera.skillarrow:setVisible(false)
                animations.model.arrowspin:stop()
                animations.model.onarrow:stop()
	end
        if (player:getItem(2).id == "minecraft:bow") and (player:getItem(1).id == "minecraft:trident") then
                action_wheel:setPage(mainPage)
                models.model.Camera.skillarrow:setVisible(false)
	end
        if (player:getItem(2).id == "minecraft:bow") and player:getActiveItem():getUseAction() == "BOW" then
		models.model.Itemgasharpoon:setVisible(true)
		models.model.Player.UpperBody.LeftArm.gasharpoon:setVisible(true)
		models.model.Player.UpperBody.LeftArm.MLA:setVisible(false)
                models.model.Camera.skillarrow:setVisible(true)
                animations.model.arrowspin:play()

                local random = vec(
                math.random() * 0,
                math.random() * 0.1,
                math.random() * 0)
                particles:newParticle("campfire_signal_smoke", models.model.Player.UpperBody.LeftArm.gasharpoon.ghp2.ghpglow.ghpptc:partToWorldMatrix():apply() + vec(0, 0, 0) + random)
                :setColor(0.85, 0.3, 1)
                :setScale(1.5)
                :setPower(-0.001)
                :setLifetime(5)

                local random1 = math.random() - 0.5
                local random2 = math.random() - 0.5
                local random3 = math.random() - 0.5
                local rVector = vec(random1, random2, random3)
                particles:newParticle("electric_spark", models.model.Player.UpperBody.LeftArm.gasharpoon.ghp2.ghpglow.ghpptc:partToWorldMatrix():apply(), rVector)
                :setLifetime(10)
        end
        if (player:getItem(1).id == "minecraft:shield") then
		models.model.Itemshield:setVisible(true)
		models.model.Player.UpperBody.RightArm.MRA.harpoon:setVisible(true)
                models.model.Camera.defense:setVisible(true)
                animations.model.defensespin:play()
        end
        if not (player:getItem(1).id == "minecraft:shield") then
		models.model.Itemshield:setVisible(false)
                models.model.Camera.defense:setVisible(false)
                animations.model.defensespin:stop()
        end
        if (player:getItem(2).id == "minecraft:shield") and (player:getItem(1).id == "minecraft:trident") then
		models.model.Itemshield:setVisible(true)
        end
        if (player:getItem(1).id == "minecraft:shield") and player:isBlocking() then
		models.model.Itemshield:setVisible(true)
                models.model.Camera.defense:setVisible(true)
                animations.model.defensespin:stop()
        end
        if (player:getItem(1).id == "minecraft:shield") and (player:getItem(2).id == "minecraft:bow") then
                models.model.Camera.skillarrow:setVisible(false)
                animations.model.arrowspin:stop()
        end
        if world.getTime() % 40 == 0 then
                local random = vec(
                math.random() * 0,
                math.random() * 0.1,
                math.random() * 0)
                particles:newParticle("smoke", models.model.Player.UpperBody.MHead.pipe.pptc:partToWorldMatrix():apply() + vec(0, 0, 0) + random)
        end
end

