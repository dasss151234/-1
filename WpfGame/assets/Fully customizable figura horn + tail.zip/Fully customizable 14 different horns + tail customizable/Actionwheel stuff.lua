-- Hi :D
-- I did not sort my actionwheel stuff at all it's an insane mess
-- I apologize

--action wheel stuff
local mainPage = action_wheel:newPage()
local secondPage = action_wheel:newPage()
local thirdPage = action_wheel:newPage()
local fourthPage = action_wheel:newPage()
local fifthPage = action_wheel:newPage()
local sixthPage = action_wheel:newPage()
local seventhPage = action_wheel:newPage()
local eitghtPage = action_wheel:newPage()
local minselanious = action_wheel:newPage()
local ninthPage = action_wheel:newPage()

action_wheel:setPage(thirdPage)


-- page 3 to 1st
local toSecond = thirdPage:newAction()
    :title("Horn madness")
    :item("minecraft:goat_horn")
    :onLeftClick(function()
    action_wheel:setPage(mainPage)
end)

local toThird = mainPage:newAction()
    :title("Main page")
    :item("glow_item_frame")
    :onLeftClick(function()
    action_wheel:setPage(thirdPage)
    end)

local toThird = secondPage:newAction()
    :title("3rd Page")
    :item("goat_horn")
    :onLeftClick(function()
    action_wheel:setPage(ninthPage)
    end)
local toThird = ninthPage:newAction()
    :title("2nd Page")
    :item("goat_horn")
    :onLeftClick(function()
    action_wheel:setPage(secondPage)
    end)
    -- 1
local action1 = mainPage:newAction()
action1:title("Horn1")
action1:item("minecraft:blue_wool")
action1:hoverColor(0,0,1)
function pings.action1Clicked(state)
  if state then
	models.Horns.Head2.Horn1:setVisible(true)
	else
	models.Horns.Head2.Horn1:setVisible(false)
	end
end
action1:onToggle(pings.action1Clicked)

-- 2
local action2 = mainPage:newAction()
action2:title("Horn2")
action2:item("minecraft:blue_wool")
action2:hoverColor(0,0,1)
function pings.action2Clicked(state)
  if state then
	models.Horns.Head2.Horn2:setVisible(true)
	else
	models.Horns.Head2.Horn2:setVisible(false)
	end
end
action2:onToggle(pings.action2Clicked)

-- 3
local action3 = mainPage:newAction()
action3:title("Horn3")
action3:item("minecraft:blue_wool")
action3:hoverColor(0,0,1)
function pings.action3Clicked(state)
  if state then
	models.Horns.Head2.Horn3:setVisible(true)
	else
	models.Horns.Head2.Horn3:setVisible(false)
	end
end
action3:onToggle(pings.action3Clicked)

-- 4
local action4 = mainPage:newAction()
action4:title("Horn4")
action4:item("minecraft:blue_wool")
action4:hoverColor(0,0,1)
function pings.action4Clicked(state)
  if state then
	models.Horns.Head2.Horn4:setVisible(true)
	else
	models.Horns.Head2.Horn4:setVisible(false)
	end
end
action4:onToggle(pings.action4Clicked)

-- 5
local action5 = mainPage:newAction()
action5:title("Horn5")
action5:item("minecraft:blue_wool")
action5:hoverColor(0,0,1)
function pings.action5Clicked(state)
  if state then
	models.Horns.Head2.Horn5:setVisible(true)
	else
	models.Horns.Head2.Horn5:setVisible(false)
	end
end
action5:onToggle(pings.action5Clicked)

-- 6
local action6 = mainPage:newAction()
action6:title("Horn6")
action6:item("minecraft:blue_wool")
action6:hoverColor(0,0,1)
function pings.action6Clicked(state)
  if state then
	models.Horns.Head2.Horn6:setVisible(true)
	else
	models.Horns.Head2.Horn6:setVisible(false)
	end
end
action6:onToggle(pings.action6Clicked)

-- page
local toSecond = mainPage:newAction()
    :title("2nd Page")
    :item("minecraft:goat_horn")
    :onLeftClick(function()
    action_wheel:setPage(secondPage)
end)

local toMain = secondPage:newAction()
    :title("1st page")
    :item("minecraft:goat_horn")
    :onLeftClick(function()
    action_wheel:setPage(mainPage)
    end)
-- Second page thingy

-- 7
local action7 = secondPage:newAction()
action7:title("Horn7")
action7:item("minecraft:blue_wool")
action7:hoverColor(0,0,1)
function pings.action7Clicked(state)
  if state then
	models.Horns.Head2.Horn7:setVisible(true)
	else
	models.Horns.Head2.Horn7:setVisible(false)
	end
end
action7:onToggle(pings.action7Clicked)

-- 8
local action8 = secondPage:newAction()
action8:title("Horn8")
action8:item("minecraft:blue_wool")
action8:hoverColor(0,0,1)
function pings.action8Clicked(state)
  if state then
	models.Horns.Head2.Horn8:setVisible(true)
	else
	models.Horns.Head2.Horn8:setVisible(false)
	end
end
action8:onToggle(pings.action8Clicked)

-- 9
local action9 = secondPage:newAction()
action9:title("Horn9")
action9:item("minecraft:blue_wool")
action9:hoverColor(0,0,1)
function pings.action9Clicked(state)
  if state then
	models.Horns.Head2.Horn9:setVisible(true)
	else
	models.Horns.Head2.Horn9:setVisible(false)
	end
end
action9:onToggle(pings.action9Clicked)

-- 10
local action10 = secondPage:newAction()
action10:title("Horn10")
action10:item("minecraft:blue_wool")
action10:hoverColor(0,0,1)
function pings.action10Clicked(state)
  if state then
	models.Horns.Head2.Horn10:setVisible(true)
	else
	models.Horns.Head2.Horn10:setVisible(false)
	end
end
action10:onToggle(pings.action10Clicked)

-- 11
local action11 = secondPage:newAction()
action11:title("Horn11")
action11:item("minecraft:blue_wool")
action11:hoverColor(0,0,1)
function pings.action11Clicked(state)
  if state then
	models.Horns.Head2.Horn11:setVisible(true)
	else
	models.Horns.Head2.Horn11:setVisible(false)
	end
end
action11:onToggle(pings.action11Clicked)

-- 12
local action12 = secondPage:newAction()
action12:title("Horn12")
action12:item("minecraft:blue_wool")
action12:hoverColor(0,0,1)
function pings.action12Clicked(state)
  if state then
	models.Horns.Head2.Horn12:setVisible(true)
	else
	models.Horns.Head2.Horn12:setVisible(false)
	end
end
action12:onToggle(pings.action12Clicked)

-- 13
local action13 = ninthPage:newAction()
action13:title("Horn13")
action13:item("minecraft:blue_wool")
action13:hoverColor(0,0,1)
function pings.action13Clicked(state)
  if state then
	models.Horns.Head2.Horn13:setVisible(true)
	else
	models.Horns.Head2.Horn13:setVisible(false)
	end
end
action13:onToggle(pings.action13Clicked)

-- 14
local action131 = ninthPage:newAction()
action131:title("Horn14")
action131:item("minecraft:blue_wool")
action131:hoverColor(0,0,1)
function pings.action131Clicked(state)
  if state then
	models.Horns.Head2.Horn14:setVisible(true)
	else
	models.Horns.Head2.Horn14:setVisible(false)
	end
end
action131:onToggle(pings.action131Clicked)

-- fourthpage, where like you can hide yourself n stuff

local toPlayerstuff = thirdPage:newAction()
    :title("Player stuff")
    :item("minecraft:amethyst_cluster")
    :onLeftClick(function()
    action_wheel:setPage(fourthPage)
end)

local tothirdpage = fourthPage:newAction()
    :title("mainPage")
    :item("minecraft:glow_item_frame")
    :onLeftClick(function()
    action_wheel:setPage(thirdPage)
end)

local action14 = fourthPage:newAction()
action14:title("Hide Elytras")
action14:item("minecraft:elytra")
action14:hoverColor(0,0,1)
function pings.action14Clicked(state)
  if state then
	vanilla_model.ELYTRA:setVisible(false)
	else
	vanilla_model.ELYTRA:setVisible(true)
	end
end
action14:onToggle(pings.action14Clicked)

local action15 = fourthPage:newAction()
action15:title("Hide armor")
action15:item("minecraft:diamond_chestplate")
action15:hoverColor(0,0,1)
function pings.action15Clicked(state)
  if state then
	vanilla_model.ARMOR:setVisible(false)
	else
	vanilla_model.ARMOR:setVisible(true)
	end
end
action15:onToggle(pings.action15Clicked)

local action16 = fourthPage:newAction()
action16:title("Hide Cape")
action16:item("minecraft:black_banner")
action16:hoverColor(0,0,1)
function pings.action16Clicked(state)
  if state then
	vanilla_model.Cape:setVisible(false)
	else
	vanilla_model.Cape:setVisible(true)
	end
end
action16:onToggle(pings.action16Clicked)

local action17 = fourthPage:newAction()
action17:title("Hide vanilla player")
action17:item("minecraft:player_head")
action17:hoverColor(0,0,1)
function pings.action17Clicked(state)
  if state then
	vanilla_model.Player:setVisible(false)
	else
	vanilla_model.Player:setVisible(true)
	end
end
action17:onToggle(pings.action17Clicked)


-- TAIL ACTION WHEEL STUFF

local toTailStuff = thirdPage:newAction()
    :title("Tail Stuff")
    :item("minecraft:honeycomb")
    :onLeftClick(function()
    action_wheel:setPage(fifthPage)
end)

local toTailStuff = fifthPage:newAction()
    :title("Main Page")
    :item("minecraft:glow_item_frame")
    :onLeftClick(function()
    action_wheel:setPage(thirdPage)
end)

local toTailStuff = fifthPage:newAction()
    :title("On the tail details")
    :item("minecraft:horn_coral_fan")
    :onLeftClick(function()
    action_wheel:setPage(seventhPage)
end)
local toTailStuff = seventhPage:newAction()
    :title("Tail stuff")
    :item("minecraft:honeycomb")
    :onLeftClick(function()
    action_wheel:setPage(fifthPage)
end)

local toTailStuff = fifthPage:newAction()
    :title("Tip of the tail")
    :item("minecraft:horn_coral")
    :onLeftClick(function()
    action_wheel:setPage(sixthPage)
end)
local toTailStuff = sixthPage:newAction()
    :title("Tail Stuff")
    :item("minecraft:honeycomb")
    :onLeftClick(function()
    action_wheel:setPage(fifthPage)
end)

local action19 = fifthPage:newAction()
action19:title("Tail toggle")
action19:item("minecraft:yellow_candle")
action19:hoverColor(0,0,1)
function pings.action19Clicked(state)
  if state then
	models.Tails.Body2:setVisible(false)
	else
		models.Tails.Body2:setVisible(true)
	end
end
action19:onToggle(pings.action19Clicked)

-- tip tail sharp

local action20 = sixthPage:newAction()
action20:title("Tail tip1")
action20:item("minecraft:yellow_candle")
action20:hoverColor(0,0,1)
function pings.action20Clicked(state)
  if state then
	models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.Tip.Tip1:setVisible(true)
	else
		models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.Tip.Tip1:setVisible(false)
	end
end
action20:onToggle(pings.action20Clicked)

local action21 = sixthPage:newAction()
action21:title("Tail tip2")
action21:item("minecraft:yellow_candle")
action21:hoverColor(0,0,1)
function pings.action21Clicked(state)
  if state then
	models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.Tip.Tip2:setVisible(true)
	else
		models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.Tip.Tip2:setVisible(false)
	end
end
action21:onToggle(pings.action21Clicked)

local action23 = sixthPage:newAction()
action23:title("Tail tip3")
action23:item("minecraft:yellow_candle")
action23:hoverColor(0,0,1)
function pings.action23Clicked(state)
  if state then
	models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.Tip.Tip3:setVisible(true)
	else
		models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.Tip.Tip3:setVisible(false)
	end
end
action23:onToggle(pings.action23Clicked)


local action24 = sixthPage:newAction()
action24:title("Tail tip4")
action24:item("minecraft:yellow_candle")
action24:hoverColor(0,0,1)
function pings.action24Clicked(state)
  if state then
	models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.Tip.Tip4:setVisible(true)
	else
		models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.Tip.Tip4:setVisible(false)
	end
end
action24:onToggle(pings.action24Clicked)

local action25 = sixthPage:newAction()
action25:title("Tail tip5")
action25:item("minecraft:yellow_candle")
action25:hoverColor(0,0,1)
function pings.action25Clicked(state)
  if state then
	models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.Tip.Tip5:setVisible(true)
	else
		models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.Tip.Tip5:setVisible(false)
	end
end
action25:onToggle(pings.action25Clicked)

local action26 = sixthPage:newAction()
action26:title("Tail tip6")
action26:item("minecraft:yellow_candle")
action26:hoverColor(0,0,1)
function pings.action26Clicked(state)
  if state then
	models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.Tip.Tip6:setVisible(true)
	else
		models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.Tip.Tip6:setVisible(false)
	end
end
action26:onToggle(pings.action26Clicked)

local toTailStuff = sixthPage:newAction()
    :title("2nd Page")
    :item("minecraft:horn_coral")
    :onLeftClick(function()
    action_wheel:setPage(eitghtPage)
end)

-- 8th page
local toTailStuff = eitghtPage:newAction()
    :title("1st Page")
    :item("minecraft:horn_coral")
    :onLeftClick(function()
    action_wheel:setPage(sixthPage)
end)

local action27 = eitghtPage:newAction()
action27:title("Tail tip7")
action27:item("minecraft:yellow_candle")
action27:hoverColor(0,0,1)
function pings.action27Clicked(state)
  if state then
	models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.Tip.Tip7:setVisible(true)
	else
		models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.Tip.Tip7:setVisible(false)
	end
end
action27:onToggle(pings.action27Clicked)

local action28 = eitghtPage:newAction()
action28:title("Tail tip8")
action28:item("minecraft:yellow_candle")
action28:hoverColor(0,0,1)
function pings.action28Clicked(state)
  if state then
	models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.Tip.Tip8:setVisible(true)
	else
		models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.Tip.Tip8:setVisible(false)
	end
end
action28:onToggle(pings.action28Clicked)

-- Details

local action40 = seventhPage:newAction()
action40:title("Detail U")
action40:item("minecraft:golden_carrot")
action40:hoverColor(0,0,1)
function pings.action40Clicked(state)
  if state then
	models.Tails.Body2.bone.bone2.DetailU1:setVisible(true)
	models.Tails.Body2.bone.bone2.bone3.bone4.DetailU2:setVisible(true)
	models.Tails.Body2.bone.bone2.bone3.bone4.bone5.DetailU:setVisible(true)
	else
		models.Tails.Body2.bone.bone2.DetailU1:setVisible(false)
	models.Tails.Body2.bone.bone2.bone3.bone4.DetailU2:setVisible(false)
	models.Tails.Body2.bone.bone2.bone3.bone4.bone5.DetailU:setVisible(false)
	end
end
action40:onToggle(pings.action40Clicked)

local action41 = seventhPage:newAction()
action41:title("Detail M")
action41:item("minecraft:golden_carrot")
action41:hoverColor(0,0,1)
function pings.action41Clicked(state)
  if state then
	models.Tails.Body2.bone.DetailM:setVisible(true)
	models.Tails.Body2.bone.bone2.bone3.bone4.DetailM2:setVisible(true)
	else
		models.Tails.Body2.bone.DetailM:setVisible(false)
	models.Tails.Body2.bone.bone2.bone3.bone4.DetailM2:setVisible(false)
	end
end
action41:onToggle(pings.action41Clicked)

local action42 = seventhPage:newAction()
action42:title("Detail L")
action42:item("minecraft:golden_carrot")
action42:hoverColor(0,0,1)
function pings.action42Clicked(state)
  if state then
	models.Tails.Body2.bone.DetailL:setVisible(true)
  models.Tails.Body2.bone.bone2.DetailL2:setVisible(true)
  models.Tails.Body2.bone.bone2.bone3.DetailL3:setVisible(true)
  models.Tails.Body2.bone.bone2.bone3.bone4.DetailL4:setVisible(true)
  models.Tails.Body2.bone.bone2.bone3.bone4.bone5.DetailL5:setVisible(true)
  models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.DetailL6:setVisible(true)
	else
    models.Tails.Body2.bone.DetailL:setVisible(false)
  models.Tails.Body2.bone.bone2.DetailL2:setVisible(false)
  models.Tails.Body2.bone.bone2.bone3.DetailL3:setVisible(false)
  models.Tails.Body2.bone.bone2.bone3.bone4.DetailL4:setVisible(false)
  models.Tails.Body2.bone.bone2.bone3.bone4.bone5.DetailL5:setVisible(false)
  models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.DetailL6:setVisible(false)
	end
end
action42:onToggle(pings.action42Clicked)

local action43 = seventhPage:newAction()
action43:title("Detail K")
action43:item("minecraft:golden_carrot")
action43:hoverColor(0,0,1)
function pings.action43Clicked(state)
  if state then
	models.Tails.Body2.bone.bone2.DetailK:setVisible(true)
	models.Tails.Body2.bone.bone2.bone3.bone4.DetailK2:setVisible(true)
  models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.DetailK3:setVisible(true)
	else
		models.Tails.Body2.bone.bone2.DetailK:setVisible(false)
	models.Tails.Body2.bone.bone2.bone3.bone4.DetailK2:setVisible(false)
  models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.DetailK3:setVisible(false)
	end
end
action43:onToggle(pings.action43Clicked)

local action44 = seventhPage:newAction()
action44:title("Detail H")
action44:item("minecraft:golden_carrot")
action44:hoverColor(0,0,1)
function pings.action44Clicked(state)
  if state then
	models.Tails.Body2.bone.DetailH:setVisible(true)
  models.Tails.Body2.bone.bone2.DetailH2:setVisible(true)
  models.Tails.Body2.bone.bone2.bone3.DetailH3:setVisible(true)
  models.Tails.Body2.bone.bone2.bone3.bone4.DetailH4:setVisible(true)
  models.Tails.Body2.bone.bone2.bone3.bone4.bone5.DetailH5:setVisible(true)
  models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.DetailH6:setVisible(true)
	else
	models.Tails.Body2.bone.DetailH:setVisible(false)
  models.Tails.Body2.bone.bone2.DetailH2:setVisible(false)
  models.Tails.Body2.bone.bone2.bone3.DetailH3:setVisible(false)
  models.Tails.Body2.bone.bone2.bone3.bone4.DetailH4:setVisible(false)
  models.Tails.Body2.bone.bone2.bone3.bone4.bone5.DetailH5:setVisible(false)
  models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.DetailH6:setVisible(false)
	end
end
action44:onToggle(pings.action44Clicked)


local action45 = seventhPage:newAction()
action45:title("Detail T")
action45:item("minecraft:golden_carrot")
action45:hoverColor(0,0,1)
function pings.action45Clicked(state)
  if state then
	models.Tails.Body2.bone.DetailT:setVisible(true)
  models.Tails.Body2.bone.bone2.DetailT2:setVisible(true)
  models.Tails.Body2.bone.bone2.bone3.DetailT3:setVisible(true)
  models.Tails.Body2.bone.bone2.bone3.bone4.DetailT4:setVisible(true)
  models.Tails.Body2.bone.bone2.bone3.bone4.bone5.DetailT5:setVisible(true)
  models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.DetailT6:setVisible(true)
	else
	models.Tails.Body2.bone.DetailT:setVisible(false)
  models.Tails.Body2.bone.bone2.DetailT2:setVisible(false)
  models.Tails.Body2.bone.bone2.bone3.DetailT3:setVisible(false)
  models.Tails.Body2.bone.bone2.bone3.bone4.DetailT4:setVisible(false)
  models.Tails.Body2.bone.bone2.bone3.bone4.bone5.DetailT5:setVisible(false)
  models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.DetailT6:setVisible(false)
	end
end
action45:onToggle(pings.action45Clicked)

local action46 = seventhPage:newAction()
action46:title("Detail F")
action46:item("minecraft:golden_carrot")
action46:hoverColor(0,0,1)
function pings.action46Clicked(state)
  if state then
	models.Tails.Body2.bone.DetailF:setVisible(true)
  models.Tails.Body2.bone.bone2.DetailF2:setVisible(true)
  models.Tails.Body2.bone.bone2.bone3.DetailF3:setVisible(true)
  models.Tails.Body2.bone.bone2.bone3.bone4.DetailF4:setVisible(true)
  models.Tails.Body2.bone.bone2.bone3.bone4.bone5.DetailF5:setVisible(true)
  models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.DetailF6:setVisible(true)
	else
	models.Tails.Body2.bone.DetailF:setVisible(false)
  models.Tails.Body2.bone.bone2.DetailF2:setVisible(false)
  models.Tails.Body2.bone.bone2.bone3.DetailF3:setVisible(false)
  models.Tails.Body2.bone.bone2.bone3.bone4.DetailF4:setVisible(false)
  models.Tails.Body2.bone.bone2.bone3.bone4.bone5.DetailF5:setVisible(false)
  models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.DetailF6:setVisible(false)
	end
end
action46:onToggle(pings.action46Clicked)

-- Minsecialous
-- Things taht don't fit in any action wheel pages

local toTailStuff = thirdPage:newAction()
    :title("Misc")
    :item("minecraft:glass_bottle")
    :onLeftClick(function()
    action_wheel:setPage(minselanious)
end)
local toTailStuff = minselanious:newAction()
    :title("Main Page")
    :item("minecraft:glow_item_frame")
    :onLeftClick(function()
    action_wheel:setPage(thirdPage)
end)

local action31 = minselanious:newAction()
action31:title("Lil Wings")
action31:item("minecraft:feather")
action31:hoverColor(0,0,1)
function pings.action31Clicked(state)
  if state then
	models.Horns.Misc.Body2.Wings:setVisible(true)
	else
		models.Horns.Misc.Body2.Wings:setVisible(false)
	end
end
action31:onToggle(pings.action31Clicked)

local action30 = minselanious:newAction()
action30:title("Elf Ears")
action30:item("minecraft:feather")
action30:hoverColor(0,0,1)
function pings.action30Clicked(state)
  if state then
	models.Horns.Misc.Head3.ElfEars:setVisible(true)
	else
		models.Horns.Misc.Head3.ElfEars:setVisible(false)
	end
end
action30:onToggle(pings.action30Clicked)

-- I found these codes for color in a random folder of an old figura a friend had me fix, I don't know who made em but I love you whoever you are

local page = action_wheel:newPage()

-- Adjustable color variables (initial values set to full color)
local hue, saturation, brightness = 0, 1, 1 -- Initial hue, full saturation, full brightness

-- Default (base) color values for the texture (neutral gray color)
local defaultHue, defaultSaturation, defaultBrightness = 0, 0, 0.5  -- Base color (gray or neutral)

-- Function to set model color based on HSV values
function pings.setColorFromHSV(hue, saturation, brightness)
    local r, g, b = convertHSVtoRGB(hue, saturation, brightness)
    models.Horns.Misc:setColor(r, g, b)
    models.Horns.Head2:setColor(r, g, b)
    models.Tails.Body2:setColor(r, g, b)
end

-- Function to convert HSV to RGB
function convertHSVtoRGB(h, s, v)
    local i = math.floor(h * 6)
    local f = h * 6 - i
    local p = v * (1 - s)
    local q = v * (1 - f * s)
    local t = v * (1 - (1 - f) * s)

    i = i % 6

    if i == 0 then
        return v, t, p
    elseif i == 1 then
        return q, v, p
    elseif i == 2 then
        return p, v, t
    elseif i == 3 then
        return p, q, v
    elseif i == 4 then
        return t, p, v
    else
        return v, p, q
    end
end

-- Helper function to apply the current color settings to the model
local function updateModelColor()
    pings.setColorFromHSV(hue, saturation, brightness)
end

-- Action to cycle hue
page:newAction()
    :title("Cycle Hue")
    :item("minecraft:red_wool")
    :onLeftClick(function()
        -- If the model is at the base gray color (hue == 0), we start cycling from a non-zero hue
        if hue == defaultHue and saturation == defaultSaturation and brightness == defaultBrightness then
            hue, saturation, brightness = 0, 1, 1  -- Start cycling from a slight hue change, not gray (hue=0)
        else
            -- Otherwise, just continue cycling the hue
            hue = (hue + 0.1) % 1  -- Adjust hue and wrap around at 1
        end
        updateModelColor()  -- Reapply color after hue change
    end)

-- Action to reset color (removes any added color, reverts to the original base color)
page:newAction()
    :title("Reset Color")
    :item("minecraft:white_dye")
    :onLeftClick(function()
        -- Reset to the default base color (neutral gray)
        hue, saturation, brightness = defaultHue, defaultSaturation, defaultBrightness
        updateModelColor()  -- Reapply the base color (gray)
    end)
-- Action to set color to black
page:newAction()
    :title("Dark Gray")
    :item("minecraft:gray_wool")  -- You can keep the texture as black_wool, but the color will be adjusted
    :onLeftClick(function()
        -- Set color to a dark gray (hue = 0, saturation = 0, brightness = 0.1)
        hue, saturation, brightness = 0, 0, 0.3  -- Dark gray
        updateModelColor()  -- Reapply color (dark gray)
    end)
	
page:newAction()
    :title("Black")
    :item("minecraft:black_wool")  -- You can keep the texture as black_wool, but the color will be adjusted
    :onLeftClick(function()
        -- Set color to a dark gray (hue = 0, saturation = 0, brightness = 0.1)
        hue, saturation, brightness = 0, 0, 0.1  -- Dark gray
        updateModelColor()  -- Reapply color (dark gray)
    end)

-- Action to set color to white
page:newAction()
    :title("White")
    :item("minecraft:white_wool")
    :onLeftClick(function()
        -- Set color to white (hue = 0, saturation = 0, brightness = 1)
        hue, saturation, brightness = 0, 0, 1  -- White
        updateModelColor()  -- Reapply color (white)
    end)

    local toTailStuff = page:newAction()
    :title("Main Page")
    :item("minecraft:glow_item_frame")
    :onLeftClick(function()
    action_wheel:setPage(thirdPage)
end)

    local toTailStuff = thirdPage:newAction()
    :title("Color changer")
    :item("minecraft:nether_star")
    :onLeftClick(function()
    action_wheel:setPage(page)
end)