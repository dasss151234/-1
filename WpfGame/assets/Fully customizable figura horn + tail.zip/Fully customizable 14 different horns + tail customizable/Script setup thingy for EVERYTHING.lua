--requires--
local squapi = require("lib.SquAPI")

--SquAPI Tail--
local myTail = {
	models.Tails.Body2.bone,
	models.Tails.Body2.bone.bone2,
	models.Tails.Body2.bone.bone2.bone3,
	models.Tails.Body2.bone.bone2.bone3.bone4,
	models.Tails.Body2.bone.bone2.bone3.bone4.bone5,
	models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6,
    models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.Tip.Tip5,
    --tail segments go here
}
--replace each nil with the value/parmater you want to use, or leave as nil to use default values :)
--parenthesis are default values for reference
squapi.tail:new(myTail,
    8,    --(15) idleXMovement
    0,    --(5) idleYMovement
    1,    --(1.2) idleXSpeed
    2,    --(2) idleYSpeed
    2,    --(2) bendStrength
    0,    --(0) velocityPush
    0,    --(0) initialMovementOffset
    0,    --(1) offsetBetweenSegments
    0.005,    --(.005) stiffness
    0.9,    --(.9) bounce
    0,    --(90) flyingOffset
    -90,    --(-90) downLimit
    90     --(45) upLimit
)


function events.render()
    if player:isCrouching() then
	models.Tails.Body2:setRot(20,0,0)
    models.Tails.Body2:setPos(0,2,3.5)
    else
	models.Tails.Body2:setRot(0,0,0)
    models.Tails.Body2:setPos(0,0,0)
    end
end

local physBone = require('physBoneAPI')

function events.entity_init()
	local hair = models.Tails.Body2.bone.DetailL.bone25:newPhysBone("physBone")
    local hair = models.Tails.Body2.bone.DetailL.bone26:newPhysBone("physBone")
    local hair = models.Tails.Body2.bone.DetailL.bone27:newPhysBone("physBone")
    local hair = models.Tails.Body2.bone.DetailL.bone28:newPhysBone("physBone")
	local hair = models.Tails.Body2.bone.bone2.DetailL2.bone24:newPhysBone("physBone")
	local hair = models.Tails.Body2.bone.bone2.DetailL2.bone23:newPhysBone("physBone")
	local hair = models.Tails.Body2.bone.bone2.DetailL2.bone20:newPhysBone("physBone")
    local hair = models.Tails.Body2.bone.bone2.bone3.DetailL3.bone32:newPhysBone("physBone")
    local hair = models.Tails.Body2.bone.bone2.bone3.DetailL3.bone31:newPhysBone("physBone")
    local hair = models.Tails.Body2.bone.bone2.bone3.DetailL3.bone30:newPhysBone("physBone")
    local hair = models.Tails.Body2.bone.bone2.bone3.DetailL3.bone29:newPhysBone("physBone")
    local hair = models.Tails.Body2.bone.bone2.bone3.bone4.DetailL4.bone33:newPhysBone("physBone")
    local hair = models.Tails.Body2.bone.bone2.bone3.bone4.DetailL4.bone34:newPhysBone("physBone")
    local hair = models.Tails.Body2.bone.bone2.bone3.bone4.DetailL4.bone35:newPhysBone("physBone")
    local hair = models.Tails.Body2.bone.bone2.bone3.bone4.DetailL4.bone36:newPhysBone("physBone")
    local hair = models.Tails.Body2.bone.bone2.bone3.bone4.bone5.DetailL5.bone37:newPhysBone("physBone")
    local hair = models.Tails.Body2.bone.bone2.bone3.bone4.bone5.DetailL5.bone38:newPhysBone("physBone")
    local hair = models.Tails.Body2.bone.bone2.bone3.bone4.bone5.DetailL5.bone39:newPhysBone("physBone")
    local hair = models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.DetailL6.bone40:newPhysBone("physBone")
    local hair = models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.DetailL6.bone41:newPhysBone("physBone")
    local hair = models.Tails.Body2.bone.bone2.bone3.bone4.bone5.bone6.DetailL6.bone42:newPhysBone("physBone")

  hair:setNodeRadius(6)
    :setNodeDensity(10)
    :setNodeEnd(100)
    :setVecMod(10,10,10)
    :setBounce(0.3)
    :setLength(10)
end
