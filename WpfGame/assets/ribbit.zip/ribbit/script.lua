local anims = require("JimmyAnims")
anims(animations.ribbit)
vanilla_model.PLAYER:setVisible(false)
vanilla_model.ARMOR:setVisible(false)
vanilla_model.CAPE:setVisible(false)
vanilla_model.ELYTRA:setVisible(false)

function events.entity_init()

end

function events.tick()
  animations.ribbit.walk:setSpeed(player:getVelocity().xz:length()*7)
  animations.ribbit.sprint:setSpeed(player:getVelocity().xz:length()*9.1)
end

--render event, called every time your avatar is rendered
--it have two arguments, "delta" and "context"
--"delta" is the percentage between the last and the next tick (as a decimal value, 0.0 to 1.0)
--"context" is a string that tells from where this render event was called (the paperdoll, gui, player render, first person)
function events.render(delta, context)
  --code goes here
end
