models.Rat.Rat:setVisible(false)
models.RatBig.Rat:setVisible(false)
models.RatBig2.Rat:setVisible(false)
models.RatBig3.Rat:setVisible(false)
models.RatBigNorm.Rat:setVisible(false)

local GSBlend = require("GSAnimBlend")
local squapi = require("SquAPI")

squapi.smoothHead(models.Rat.Rat.middle.skull, 0.3, 0.3, false)
squapi.smoothHead(models.RatBig.Rat.middle.skull, 0.3, 0.3, false)
squapi.smoothHead(models.RatBig2.Rat.middle.skull, 0.3, 0.3, false)
squapi.smoothHead(models.RatBig3.Rat.middle.skull, 0.3, 0.3, false)
squapi.smoothHead(models.RatBigNorm.Rat.middle.skull, 0.3, 0.3, false)

local myTails = {
	models.Rat.Rat.middle.tail,
	models.Rat.Rat.middle.tail.tail2,
	models.Rat.Rat.middle.tail.tail2.tail3
	}
local tailsegs = {tail,tail2,tail3}
squapi.tails(myTails)

local myTails = {
	models.RatBig.Rat.middle.tail,
	models.RatBig.Rat.middle.tail.tail2,
	models.RatBig.Rat.middle.tail.tail2.tail3
	}
local tailsegs = {tail,tail2,tail3}
squapi.tails(myTails)

local myTails = {
	models.RatBig2.Rat.middle.tail,
	models.RatBig2.Rat.middle.tail.tail2,
	models.RatBig2.Rat.middle.tail.tail2.tail3
	}
local tailsegs = {tail,tail2,tail3}
squapi.tails(myTails)

local myTails = {
	models.RatBig3.Rat.middle.tail,
	models.RatBig3.Rat.middle.tail.tail2,
	models.RatBig3.Rat.middle.tail.tail2.tail3
	}
local tailsegs = {tail,tail2,tail3}
squapi.tails(myTails)

local myTails = {
	models.RatBigNorm.Rat.middle.tail,
	models.RatBigNorm.Rat.middle.tail.tail2,
	models.RatBigNorm.Rat.middle.tail.tail2.tail3
	}
local tailsegs = {tail,tail2,tail3}
squapi.tails(myTails)


models.Rat.Rat.middle.skull.RightItemPivot:setScale(0.4, 0.4, 0.4)
models.Rat.Rat.middle.skull.LeftItemPivot:setScale(0.4, 0.4, 0.4)
models.Rat.Rat.middle.LeftElytraPivot:setScale(0.3, 0.3, 0.3)
models.Rat.Rat.middle.RightElytraPivot:setScale(0.3, 0.3, 0.3)

function events.tick()
    if math.random() > .999 and animations.Rat.idle:isPlaying() then
        animations.Rat.face:play()
    end
end

function events.tick()
    if math.random() > .999 and animations.RatBig.idle:isPlaying() then
        animations.RatBig.face:play()
    end
end

function events.tick()
    if math.random() > .999 and animations.RatBig2.idle:isPlaying() then
        animations.RatBig2.face:play()
    end
end

function events.tick()
    if math.random() > .999 and animations.RatBig3.idle:isPlaying() then
        animations.RatBig3.face:play()
    end
end

function events.tick()
    if math.random() > .999 and animations.RatBigNorm.idle:isPlaying() then
        animations.RatBigNorm.face:play()
    end
end

local Normal = true
local NormalRat = models.Rat.Rat
local HumanNorm = vanilla_model.PLAYER
local RatBig = models.RatBig.Rat
local RitBig = models.RatBig2.Rat
local RitBig2 = models.RatBig3.Rat
local RatBigNorm = models.RatBigNorm.Rat

function pings.Normal(bool)
	NormalRat:setVisible(true)
	HumanNorm:setVisible(false)
	RatBig:setVisible(false)
    RitBig:setVisible(false)
	RitBig2:setVisible(false)
	RatBigNorm:setVisible(false)
	vanilla_model.ARMOR:setVisible(false)
end

function pings.Human()
	NormalRat:setVisible(false)
	HumanNorm:setVisible(true)
	RatBig:setVisible(false)
    RitBig:setVisible(false)
	RitBig2:setVisible(false)
	RatBigNorm:setVisible(false)
	vanilla_model.ARMOR:setVisible(true)
end

function pings.Rat()
	NormalRat:setVisible(false)
	HumanNorm:setVisible(false)
	RatBig:setVisible(true)
    RitBig:setVisible(false)
	RitBig2:setVisible(false)
	RatBigNorm:setVisible(false)
	vanilla_model.ARMOR:setVisible(false)
end

function pings.Rit()
	NormalRat:setVisible(false)
	HumanNorm:setVisible(false)
	RatBig:setVisible(false)
	RitBig:setVisible(true)
	RitBig2:setVisible(false)
	RatBigNorm:setVisible(false)
	vanilla_model.ARMOR:setVisible(false)
end

function pings.Rit2()
	NormalRat:setVisible(false)
	HumanNorm:setVisible(false)
	RatBig:setVisible(false)
	RitBig:setVisible(false)
	RitBig2:setVisible(true)
	RatBigNorm:setVisible(false)
	vanilla_model.ARMOR:setVisible(false)
end

function pings.Rit3()
	NormalRat:setVisible(false)
	HumanNorm:setVisible(false)
	RatBig:setVisible(false)
	RitBig:setVisible(false)
	RitBig2:setVisible(false)
	RatBigNorm:setVisible(true)
	vanilla_model.ARMOR:setVisible(false)
end



local mainPage = action_wheel:newPage()
action_wheel:setPage(mainPage)

mainPage:newAction()
  :title("Rat")
  :item("minecraft:rotten_flesh")
  :hoverColor(1, 1, 1)
  :onLeftClick(pings.Normal)

mainPage:newAction()
  :title("Human")
  :item("minecraft:player_head")
  :hoverColor(1, 1, 1)
  :onLeftClick(pings.Human)
  
  mainPage:newAction()
  :title("Big Rat Crown")
  :item("minecraft:skeleton_skull")
  :hoverColor(1, 1, 1)
  :onLeftClick(pings.Rat)

 mainPage:newAction()
  :title("Big Rat Rat")
  :item("minecraft:wither_skeleton_skull")
  :hoverColor(1, 1, 1)
  :onLeftClick(pings.Rit)
  
  mainPage:newAction()
  :title("Big Rat Sheep")
  :item("minecraft:skeleton_spawn_egg")
  :hoverColor(1, 1, 1)
  :onLeftClick(pings.Rit2)
  
  mainPage:newAction()
  :title("Big Rat")
  :item("minecraft:wither_skeleton_spawn_egg")
  :hoverColor(1, 1, 1)
  :onLeftClick(pings.Rit3)