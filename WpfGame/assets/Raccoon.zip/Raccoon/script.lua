vanilla_model.CAPE:setVisible(false)
vanilla_model.PLAYER:setVisible(false)
vanilla_model.ELYTRA:setVisible(false)
vanilla_model.ARMOR:setVisible(false)

models.model:setVisible(true)

animations.model.idle:play()
animations.model.idle2:play()
animations.model.idle3:play()

-- crosshair setings
local pos = vectors.vec3()

local function validBlock(block)
	return block and not block:isAir()
end
function events.ENTITY_INIT() pos:set(player:getPos()) end

function events.RENDER(delta, context)
	if context == "FIRST_PERSON" then
		local entity, entityPos = player:getTargetedEntity(host:getReachDistance())
		local block, blockPos = player:getTargetedBlock(true, host:getReachDistance())
		local deltaDeltaPos = player:getPos(delta) - player:getPos()
		pos:set(entity and entityPos:add(deltaDeltaPos) or
			validBlock(block) and blockPos:add(deltaDeltaPos) or
			player:getPos(delta):add(0, player:getEyeHeight())
				:add(player:getLookDir() * host:getReachDistance())
				:add(renderer:getEyeOffset())
		)
		
		local screenSpace = vectors.worldToScreenSpace(pos)
		local coords = screenSpace.xy:add(0, 0):mul(client:getScaledWindowSize()):div(2, 2)
		
		renderer:crosshairOffset(coords)
	end
end

-- action wheel
local mainPage = action_wheel:newPage()
action_wheel:setPage(mainPage)

function pings.camera()
	renderer:setOffsetCameraPivot(0,0,0)
end

local action = mainPage:newAction()
    :title("Опустить камеру")
    :toggleTitle("Поднять камеру")
    :item("minecraft:golden_apple")
    :toggleItem("minecraft:enchanted_golden_apple")
	:toggleColor(vectors.hexToRGB("71a3d5"))
    :onToggle(function(isToggled)
        if isToggled then
            isHardlyActive = not isHardlyActive
            if isHardlyActive then
                renderer:setOffsetCameraPivot(0,-1.2,0)
            else
                renderer:setOffsetCameraPivot(0,-1.2,0)
            end
        else
            isHardlyActive = not isHardlyActive
        end
    end)
    :onLeftClick(pings.camera)