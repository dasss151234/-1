-- [[ Require ]]
local eZAnims = require("EZAnims")

-- [[ Variables ]]
local anims = animations.model
local model = models.model

local root = model.root
local bodyParts = {
    Head = root.Head
}

-- [[ Init ]]
vanilla_model.PLAYER:visible(false)
vanilla_model.CAPE:visible(false)

eZAnims:setOneJump(true)

-- base anims
anims.idle:setPriority(-1)
anims.idle:setBlendTime(3)

anims.jumpup:setBlendTime(2)
anims.jumpdown:setBlendTime(2, 3)
anims.crouchjumpup:setBlendTime(2)
anims.fall:setBlendTime(2)

anims.waterwalk:setBlendTime(12, 60)
anims.waterwalkback:setBlendTime(12, 60)

anims.flywalk:setBlendTime(10, 12)
anims.flywalkback:setBlendTime(10, 12)
anims.flysprint:setBlendTime(4, 12)
anims.flyup:setBlendTime(10, 12)
anims.flydown:setBlendTime(10, 12)

anims.hurt:setBlendTime(1, 0)

-- arms anims
anims.eatR:setPriority(1)
anims.eatL:setPriority(1)
anims.drinkR:setPriority(1)
anims.drinkL:setPriority(1)
anims.blockR:setPriority(1)
anims.blockL:setPriority(1)
anims.blockR:setBlendTime(2)
anims.blockL:setBlendTime(2)
anims.bowR:setPriority(1)
anims.bowL:setPriority(1)
anims.bowR:setBlendTime(4)
anims.bowL:setBlendTime(4)
anims.loadR:setBlendTime(5, 3)
anims.loadL:setBlendTime(5, 3)
anims.loadR:setPriority(1)
anims.loadL:setPriority(1)
anims.crossR:setBlendTime(3)
anims.crossL:setBlendTime(3)
anims.crossR:setPriority(1)
anims.crossL:setPriority(1)
anims.spyglassR:setBlendTime(2)
anims.spyglassL:setBlendTime(2)
anims.spyglassR:setPriority(1)
anims.spyglassL:setPriority(1)
anims.brushR:setPriority(1)
anims.brushL:setPriority(1)
anims.spearR:setPriority(1)
anims.spearL:setPriority(1)

-- [[ Script ]]
function events.tick()
    -- get velocity
    local forwardVel = player:getVelocity():dot((player:getLookDir().x_z):normalize())
    local horizontalVel = player:getVelocity().xz:length() * 20
    local verticalVel = player:getVelocity().y

    -- walk speed
    local walkSpeed = horizontalVel / 4.3 * (forwardVel > 0 and 1 or -1)

    -- set speed
    anims.walk:setSpeed(walkSpeed * 1.3)
    anims.sprint:setSpeed(walkSpeed * 1.1)
    anims.crouchwalk:setSpeed(walkSpeed * 3)
    anims.climb:setSpeed(verticalVel * 9)
    anims.fall:setSpeed(1 + math.abs(verticalVel/2))
    anims.waterwalk:setSpeed(walkSpeed * 2)
    anims.waterwalkback:setSpeed(walkSpeed * 2)
    anims.flywalk:setSpeed(walkSpeed * 0.8)
    anims.flywalkback:setSpeed(walkSpeed * 0.8)
    anims.flysprint:setSpeed(walkSpeed * 0.6)
    anims.elytra:setSpeed(walkSpeed * 0.6)
    anims.elytradown:setSpeed(walkSpeed * 0.6)

end

function events.render(dt)
    -- rotate head
    local targetHeadAngle = vanilla_model.Head:getOriginRot()

    bodyParts.Head:setOffsetRot(targetHeadAngle)
end