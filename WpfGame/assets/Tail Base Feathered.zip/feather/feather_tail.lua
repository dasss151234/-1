--Hello!--

--requires--
local squapi = require("lib.SquAPI")

--SquAPI Tail--
local myTail = {
	models.feather.feather_tail.root.Body.tail.base,
	models.feather.feather_tail.root.Body.tail.base.base2,
	models.feather.feather_tail.root.Body.tail.base.base2.mid1,
	models.feather.feather_tail.root.Body.tail.base.base2.mid1.mid1a
    --tail segments go here
}
--replace each nil with the value/parmater you want to use, or leave as nil to use default values :)
--parenthesis are default values for reference
squapi.tail:new(myTail,
    7.5,    --(15) idleXMovement
    2.5,    --(5) idleYMovement
    nil,    --(1.2) idleXSpeed
    nil,    --(2) idleYSpeed
    nil,    --(2) bendStrength
    nil,    --(0) velocityPush
    nil,    --(0) initialMovementOffset
    0,    --(1) offsetBetweenSegments
    0,    --(.005) stiffness
    nil,    --(.9) bounce
    nil,    --(90) flyingOffset
    nil,    --(-90) downLimit
    nil     --(45) upLimit
)