require("utils/bouncingpart")
require("utils/interpval")
local imath = require("utils/imath")
local tendrilShake = 0
local tendrilShakePrev = 0

function events.on_play_sound(id, pos, vol, pitch, loop, category)
    if tendrilShake ~= 0 then return end
    if not player:isLoaded() then return end
	
	local distance = (pos - player:getPos()):length()
    if distance > 8 then return end
    if id:find("step") and category == "PLAYERS" and distance < 2 then return end
	
	tendrilShake = 25
	tendrilShakePrev = 26
	sounds:playSound("entity.warden.tendril_clicks", player:getPos())
end

function events.tick()
	models.tendrils_model.head.left_tendril.glow:setOpacity(0)
	models.tendrils_model.head.right_tendril.glow:setOpacity(0)
end

local playerMove = InterpolatingValue:new(vectors.vec3())
local playerRot  = InterpolatingValue:new(vectors.vec2())

function events.tick()
	playerMove:update(player:getVelocity())
	playerRot:update(player:getRot())
	tendrilShakePrev = tendrilShake
	tendrilShake     = math.max(0, tendrilShake - 1)
end

local leftTendril  = BouncingPart:new(models.tendrils_model.head.left_tendril )
local rightTendril = BouncingPart:new(models.tendrils_model.head.right_tendril)
function events.render(delta, context)
	local wTime = world:getTime(delta)
	local sPercent  = (math.max(10, math.lerp(tendrilShakePrev, tendrilShake, delta)) - 10) / 20
	local pRot      = playerRot:get(delta)
	local pRotDelta = playerRot:getDelta(delta)
	local pMove     = imath.rotateVecHorizontal(playerMove:get(delta), pRot.y - 90)
	
	leftTendril.mat:reset()
	rightTendril.mat:reset()
	
	leftTendril.mat:rotateX(-pMove.x * 45)
	leftTendril.mat:rotateY(pRotDelta.y * 0.5)
	leftTendril.mat:rotateZ(-pMove.z * 25 + pMove.y * 15 - pRotDelta.y * 0.125)
	rightTendril.mat:rotateX(-pMove.x * 45)
	rightTendril.mat:rotateY(pRotDelta.y * 0.5)
	rightTendril.mat:rotateZ(-pMove.z * 25 - pMove.y * 15 + pRotDelta.y * 0.125)
	if sPercent ~= 0 then
		local shake    = math.sin(wTime * 2) * 45 * sPercent * 2
		local shake2   = math.cos(wTime * 2) * 20 * sPercent * 2
		
		leftTendril.mat:rotateX(shake)
		leftTendril.mat:rotateZ(-shake2)
		
		rightTendril.mat:rotateX(shake)
		rightTendril.mat:rotateZ(shake2)
		models.tendrils_model.head.left_tendril.glow:setColor(sPercent, sPercent, sPercent)
		models.tendrils_model.head.right_tendril.glow:setColor(sPercent, sPercent, sPercent)
	else 
		models.tendrils_model.head.left_tendril.glow:setColor(0, 0, 0)
		models.tendrils_model.head.right_tendril.glow:setColor(0, 0, 0)
	end
	leftTendril:apply(0.98, 0.998)
	rightTendril:apply(0.98, 0.998)
end
