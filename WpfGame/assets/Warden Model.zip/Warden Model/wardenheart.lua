-- wardenheart
-- models.model.root.Body.Heart:setPrimaryRenderType("EMISSIVE")
local Heartroot = models.tendrils_model.warden.Boby.wardenHEART
root = 0
function events.render()
    hp = 1 + (20 - player:getHealth()) * 0.1
    root = root + (1 * (60 / client:getFPS())) * hp
    sine = math.sin(root * 0.05)
    Heartroot.Heart:setOpacity(math.clamp(sine,0,1))
    Heartroot.RibR:setRot(0, (sine*5.625)+7.5, 0)
    Heartroot.RibL:setRot(0, (sine*-5.625)-7.5, 0)
end