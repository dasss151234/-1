vanilla_model.PLAYER:setVisible(false)
vanilla_model.ARMOR:setVisible(false)
vanilla_model.CAPE:setVisible(false)
vanilla_model.ELYTRA:setVisible(false)

renderer:setOffsetCameraPivot(0,1.0,0)
--function events.entity_init()
--    sounds:playSound("89a85341d5ba385c95deed06cc89ee4bc2588273",player:getPos(),1,1,true)
--end
function events.tick()
    animations.tendrils_model.beating:play()
end

require("GSAnimBlend")

local anims = require("JimmyAnims")
anims(animations.tendrils_model)

-- Action Wheel --

local mainPage = action_wheel:newPage()
action_wheel:setPage(mainPage)

function pings.Roar()
    animations.tendrils_model.roar:play()
end

local Roar = mainPage:newAction()
    :title("Roar")
    :setItem("minecraft:warden_spawn_egg")
    :hoverColor(1,0,1)
    :onLeftClick(pings.Roar)

function pings.Whine()
    animations.tendrils_model.whine:play()
end
    
local Whine = mainPage:newAction()
    :title("Whine")
    :setItem("minecraft:echo_shard")
    :hoverColor(1,0,1)
    :onLeftClick(pings.Whine)

function pings.Groan()
    animations.tendrils_model.groan:play()
end
      
local Groan = mainPage:newAction()
    :title("Groan")
    :setItem("minecraft:echo_shard")
    :hoverColor(1,0,1)
    :onLeftClick(pings.Groan)

function pings.Sniff()
    animations.tendrils_model.sniff:play()
end
       
    local Sniff = mainPage:newAction()
    :title("Sniff")
    :setItem("minecraft:recovery_compass")
    :hoverColor(1,0,1)
    :onLeftClick(pings.Sniff)

    function pings.fastBeat()
        animations.tendrils_model.beating:stop()
        animations.tendrils_model.beatingFast:play()
    end
    
    function pings.slowBeat()
        animations.tendrils_model.beating:play()
        animations.tendrils_model.beatingFast:stop()
    end
    
    local Coat = mainPage:newAction()
        :title("Quick beat")
        :toggleTitle("Slow beat")
        :item("minecraft:calibrated_sculk_sensor")
        :toggleItem("minecraft:sculk_sensor")
        :hoverColor(1, 0, 1)
        :onToggle(pings.fastBeat)
        :onUntoggle(pings.slowBeat)