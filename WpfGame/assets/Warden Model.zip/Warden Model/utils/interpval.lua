---@class InterpolatingValue
---@field previous  number | Vector2 | Vector3
---@field current   number | Vector2 | Vector3
---@field prevDelta number | Vector2 | Vector3
--@field delta     number | Vector2 | Vector3
InterpolatingValue = {}


---@return InterpolatingValue
function InterpolatingValue:new(start)
	local iVal = {
		previous = start, current = start
	}

	setmetatable(iVal, self)
    self.__index = self
	return iVal
end

function InterpolatingValue:get(delta)
	return math.lerp(self.previous, self.current, delta)
end
function InterpolatingValue:getDelta(delta)
	return math.lerp(self.prevDelta, self.current - self.previous, delta)
end
--function InterpolatingValue:getDiff(delta)
--	return math.lerp(self.previous, self.current, delta)
--end

function InterpolatingValue:update(newVal)
	self.prevDelta = self.current - self.previous
	self.previous = self.current
	--self.prevDelta = self.delta
	self.current = newVal
	--self.delta = self.current - self.previous
end

