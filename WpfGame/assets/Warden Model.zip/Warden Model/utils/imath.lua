---@class IanMath
local IanMath = {}

---@param m Matrix4
function IanMath.matrix4ToEuler(m)
	local rotXangle = math.atan2(-m.r2.z, m.r3.z);

	local cosYangle = math.sqrt(math.pow(m.r1.x, 2) + math.pow(m.r1.y, 2));
	local rotYangle = math.atan2(m.r1.z, cosYangle);

	local sinXangle = math.sin(rotXangle);
	local cosXangle = math.cos(rotXangle);
	local rotZangle = math.atan2(cosXangle * m.r2.x + sinXangle * m.r3.x, cosXangle * m.r2.y + sinXangle * m.r3.y);

	return vec(math.deg(rotXangle), math.deg(rotYangle), math.deg(rotZangle))
end

function IanMath.angleDiffDeg(degA, degB)
	local diff = nil

	if type(degA) == "Vector2" or type(degA) == "Vector3" then
		local mod360 = function(v) return math.fmod(v, 360) end
		diff = ((degB - degA) + 180):applyFunc(mod360) - 180

		local normDeg = function(v) return (v < -180 and {v + 360} or {v})[1] end
		diff:applyFunc(normDeg)
		return diff
	else
		diff = (math.fmod((degB - degA) + 180, 360)) - 180
		if diff < -180 then diff = diff + 360 end
	end

	return diff
end

function IanMath.bounceLerpAngle(a, b, v, stiff, bounce)
	stiff = 1 - stiff
	bounce = 1 - bounce

	local diff = IanMath.angleDiffDeg(a, b)
	return (a + v) + (diff * bounce), v + ((diff - v * stiff) * stiff)
end

---@generic T: Vector2 | Vector3
---
---@param v T
---@param deg any
---@return T
function IanMath.rotateVecHorizontal(v, deg)
	local rVec = v:copy()
	local rad = math.rad(deg)
	local c, s = math.cos(rad), math.sin(rad)

	if type(rVec) == "Vector2" then
		rVec.x =  c * v.x + s * v.y
		rVec.y = -s * v.x + c * v.y
	end
	if type(rVec) == "Vector3" then
		rVec.x =  c * v.x + s * v.z
		rVec.z = -s * v.x + c * v.z
	end
	return rVec
end

return IanMath