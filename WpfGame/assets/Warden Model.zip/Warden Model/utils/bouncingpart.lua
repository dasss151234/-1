local imath = require("utils/imath")

---@class BouncingPart
---@field mat  Matrix4
---@field rot  Vector3
---@field vel  Vector3
---@field part ModelPart
BouncingPart = {}


---@param part ModelPart
---@return BouncingPart
function BouncingPart:new(part)
	local bPart = {
		mat = matrices.mat4(),
		rot = vec(0, 0, 0),
		vel = vec(0, 0, 0),
		part = part
	}

	setmetatable(bPart, self)
    self.__index = self
	return bPart
end

function BouncingPart:apply(bounce, stiff, limitFunc)
	self.rot, self.vel = imath.bounceLerpAngle(
		self.rot,
		imath.matrix4ToEuler(self.mat),
		self.vel,
		stiff, bounce
	)
	if limitFunc ~= nil then
		self.part:setRot(limitFunc(self.rot))
	else
		self.part:setRot(self.rot)
	end
end

