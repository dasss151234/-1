local mainPage = action_wheel:newPage()
action_wheel:setPage(mainPage)

function pings.popa() -- don't forget to change the name if you're re-using this
    animations.model.idle:play()
    -- one of the most common things to do is play an animation (like an emote wheel)
    -- you'll need to fill out the path to your Blockbench model and name of the animation to use this
    -- animations["<MODEL PATH HERE>"]["<ANIMATION NAME HERE>"]:play()
end
function pings.nig()
    animations.model.rotat:play()
end




local action = mainPage:newAction()
    :title("мега кал анимация")
    :item("minecraft:apple")
    :hoverColor(1, 0, 1)
    :onLeftClick(pings.popa)

local action = mainPage:newAction()
    :title("переворот")
    :item("minecraft:feather")
    :hoverColor(1, 0, 1)
    :onLeftClick(pings.nig)

function pings.of(state)
    vanilla_model.ARMOR:setVisible(state)
    -- animation toggle example (commented out to avoid erroring):
    -- animations.bbmodelname.animationname:setPlaying(state)
end

local toggleaction = mainPage:newAction() -- If you're getting an error here it's probably because you didn't make the page
    :title("нету брони")
    :toggleTitle("есть броня")
    :item("red_bed")
    :toggleItem("smithing_table")
    :setOnToggle(pings.of)

    function pings.toggling(state)
    models:setVisible(state)
    -- animation toggle example (commented out to avoid erroring):
    -- animations.bbmodelname.animationname:setPlaying(state)
end

local toggleaction = mainPage:newAction() -- If you're getting an error here it's probably because you didn't make the page
    :title("шляпы нет")
    :toggleTitle("шляпа тут")
    :item("brown_egg")
    :toggleItem("blue_egg")
    :setOnToggle(pings.toggling)

local action = mainPage:newAction()
    :title("?")
    :item("minecraft:command_block")
    :hoverColor(1, 0, 1)
    -- the onLeftClick function just sets the Action's leftClick field
    :onLeftClick(function()
        print("Владик самый крутой в мире пупс и он молодец правда правда и Максим тоже и Мотя тоже крутой")
    end)
    -- script by arkanite