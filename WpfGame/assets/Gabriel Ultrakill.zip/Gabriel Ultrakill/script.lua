-- Auto generated script file --

--hide vanilla model
vanilla_model.PLAYER:setVisible(false)

--hide vanilla armor model
vanilla_model.ARMOR:setVisible(false)

--hide vanilla cape model
vanilla_model.CAPE:setVisible(false)

--hide vanilla elytra model
vanilla_model.ELYTRA:setVisible(false)

models:setSecondaryRenderType("Eyes")

local anims = require("JimmyAnims")
anims(animations.model)

function events.item_render(item)
    if item.id == "minecraft:diamond_sword" then
        return models.item.ItemSword
    end
end

function events.item_render(item)
    if item.id == "minecraft:trident" then
        return models.item.ItemSpear
    end
end

local mainPage = action_wheel:newPage()
action_wheel:setPage(mainPage)

function pings.WingToggle(state)
    
    models.model.Elytra:setVisible(state)
end

local toggleaction = mainPage:newAction()
        :title("Enable Wings")
    :toggleTitle("Disable Wings")
    :item("red_wool")
    :toggleItem("green_wool")
    :setOnToggle(pings.WingToggle) 

function pings.HaloToggle(state)
    
    models.model.Halo:setVisible(state)
end

local toggleaction = mainPage:newAction()
        :title("Enable Halo")
    :toggleTitle("Disable Halo")
    :item("red_wool")
    :toggleItem("green_wool")
    :setOnToggle(pings.HaloToggle) 