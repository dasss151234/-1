


local camDist = 0

events.RENDER:register(function (delta, context)
  local cameraPos = client:getCameraPos()
  local playerPos = player:getPos()
  if cameraPos.y>playerPos.y+2 then
    cameraPos.y=cameraPos.y-2
  elseif cameraPos.y>playerPos.y then
    cameraPos.y=playerPos.y
  end
  camDist = (cameraPos-playerPos):length()
end)


models.skull.Skull.black_hole.Rings.OrangeRing:setPreRender(function()


    local s = 1+0.15/math.clamp(camDist-1,0.25,1)


    --comment this out if you don't want t

    
    --move it behind the avatar visually

    models.skull.Skull.black_hole.Rings.OrangeRing:setMatrix(matrices.mat4(
      vectors.vec4(s,0,0,0),
      vectors.vec4(0,s,0,0),
      vectors.vec4(0,0,s,0),
      vectors.vec4(0,0,0,s)
    ))


  end)

--setToonShader(models.black_hole,1,vec(0,0,0),true,true,false,false)
models.skull.Skull.black_hole:setParentType("Camera")

models.skull.Skull.black_hole:setPrimaryRenderType("Emissive_Solid")
--models.skull.Skull.black_hole.outline:setPrimaryRenderType("CUTOUT_CULL")
models.skull.Skull.black_hole.outline:setScale(-1)
models.skull.Skull.black_hole.outline:setPrimaryRenderType("Emissive_Solid")
models.skull.Skull.black_hole.outline2:setScale(-1)
models.skull.Skull.black_hole.outline2:setPrimaryRenderType("TEXTURED_PORTAL")
models.skull.Skull.black_hole.outline3:setScale(-1)
models.skull.Skull.black_hole.outline3:setPrimaryRenderType("Emissive_Solid")
models.skull.Skull.black_hole.Rings.OrangeRing:setScale(-1)
models.skull.Skull.black_hole.Rings.OrangeRing:setPrimaryRenderType("TEXTURED_PORTAL")
models.skull.Skull.black_hole.InnerLayer.WhiteSphere:setScale(-1)
models.skull.Skull.black_hole.InnerLayer.WhiteSphere:setPrimaryRenderType("Emissive_Solid")
