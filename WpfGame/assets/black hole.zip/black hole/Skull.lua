 --123yeah_boi321's SQUASHSCRIPT
local heads = {}
local skull_model = (models.skull.Skull.Head)

local DURATION = 10

function events.world_tick()
	local count = 0
    for i,v in pairs(heads) do 
        count = count + 1
        v.stretch = v.stretch + 1
        if v.stretch >= DURATION then heads[i] = nil end
    end
	
end

--easing modified from GNTweenLib
local snd = sounds["QuasarLoop"]

animations.skull.pulse:play()


function events.SKULL_RENDER(delta,block,item,entity,type)

    if type == "BLOCK" then
        local blockk = world.getBlockState(block:getPos())

            models.skull.Skull.Head:setVisible(false)
            models.skull.Skull.black_hole:setVisible(true)

            skullpos = block:getPos()
        snd:pos(skullpos):loop(true):play()

            --sounds:playSound("sound",block:getPos(),1, 1)
            --sounds:playSound("QuasarLoop",block:getPos(),1, 1)
    if blockk:getID() ~= "minecraft:player_head" then
        snd:stop()
    end

	else
        models.skull.Skull.Head:setVisible(true)
        models.skull.Skull.black_hole:setVisible(false)

end
end

-- time, begin, change, duration, aplitude, period


--sounds:playSound("use",block:getPos(),0.4, 1,true)


