-- Auto generated script file --

--hide vanilla armor model
vanilla_model.ARMOR:setVisible(false)

--hide vanilla cape model
vanilla_model.CAPE:setVisible(false)

--hide vanilla elytra model
vanilla_model.ELYTRA:setVisible(false)
vanilla_model.ALL:setVisible(false)
 
require("GSAnimBlend")

local squapi = require("SquAPI")

local anims = require("JimmyAnims")
anims(animations.model)

local SwingingPhysics = require("swinging_physics")
local swingOnHead = SwingingPhysics.swingOnHead
local swingOnBody = SwingingPhysics.swingOnBody
squapi.eye:new(models.model.root.Torso.Head.eyes.l.LeftPupil, 0.1, 0.7, 0.5, 0.25)
squapi.eye:new(models.model.root.Torso.Head.eyes.r.RightPupil, 0.7, 0.1, 0.5, 0.25)
squapi.randimation:new(animations.model.default2) --blink
squapi.smoothHead:new(
		    {
		        models.model.root.Torso.Head,
		        nil --element(you can have multiple elements in a table)
		    },
		    {
		        0.7, 0.3 --(1) strength(you can have multiple strengths in a table)
		    },
		    nil,    --(0.1) tilt
		    nil,    --(1) speed
		    nil     --(true) keepOriginalHeadPos
)
squapi.smoothHead:new(
		    {
		        models.model.root.Torso,
		        nil --element(you can have multiple elements in a table)
		    },
		    {
		        0.3, 0.05 --(1) strength(you can have multiple strengths in a table)
		    },
		    nil,    --(0.1) tilt
		    nil,    --(1) speed
		    nil     --(true) keepOriginalHeadPos
)
squapi.bounceWalk:new(
    models.model,    --model
    1     --(1) bounceMultiplier
)

swingOnHead(models.model.root.Torso.Head.Volosi.bone10, 0, {-60,10,0,0,-10,10})
swingOnBody(models.model.root.Torso.Body.top.bone, 0, {-10,10,0,0,-10,10})
swingOnHead(models.model.root.Torso.Head.naushniki, 0, {-1,10,0,0,-10,10})
swingOnHead(models.model.root.Torso.Head.Volosi.pered.Right, 90, {-5,50,-0,0,-5,7}, nil, 1)
swingOnHead(models.model.root.Torso.Head.Volosi.pered.Left, 90, {-5,50,-0,0,-5,7}, nil, 1)