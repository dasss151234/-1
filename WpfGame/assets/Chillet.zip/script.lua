-- Vanilla
vanilla_model.PLAYER:setVisible(false)
vanilla_model.ARMOR:setVisible(false)
vanilla_model.CAPE:setVisible(false)

-- Dependacies
require("scripts.GSAnimBlend")
local squapi = require("scripts.SquAPI")

--Shield to tail
local tailRightPivot = models.chillet.root.main.torso5.torso6.torso7.torso8.RightItemPivot2
local tailLeftPivot = models.chillet.root.main.torso5.torso6.torso7.torso8.LeftItemPivot2
local headRightPivot = models.chillet.root.main.torso4.torso3.torso2.torso.Head.RightItemPivot
local headLeftPivot = models.chillet.root.main.torso4.torso3.torso2.torso.Head.LeftItemPivot

tailRightPivot:setVisible(false)
tailLeftPivot:setVisible(false)

function events.item_render(item, mode, pos, rot, scale, left)
    if left then
        if item:getID() == "minecraft:shield" then
            tailLeftPivot:setVisible(true)
            headLeftPivot:setVisible(false)
        else
            headLeftPivot:setVisible(true)
            tailLeftPivot:setVisible(false)
        end
    else
        if item:getID() == "minecraft:shield" then
            tailRightPivot:setVisible(true)
            headRightPivot:setVisible(false)
        else
            headRightPivot:setVisible(true)
            tailRightPivot:setVisible(false)
        end
    end
end

--SquaAPI
squapi.smoothHead:new(
    {
        models.chillet.root.main.torso4.torso3.torso2.torso.Head,
        models.chillet.root.main.torso4.torso3.torso2.torso,
        models.chillet.root.main.torso4.torso3.torso2
    },
    nil,   --strength
    nil,   --tilt
    nil,   --speed
    false, --keepOriginalHeadPos
    nil,   --fixPortrait
    nil,   --animStraightenList
    nil,   --straightenMultiplier
    nil,   --straightenSpeed
    nil    --blendToConsiderStopped
)

-- First Person Arm
function events.render(delta, context)
    models.chillet.root.main.torso4.torso3.Arms:setVisible(context ~= "FIRST_PERSON")
end

local mainPage = action_wheel:newPage()
action_wheel:setPage(mainPage)

function pings.toggling(state)
    models:setVisible(state)
    -- animation toggle example (commented out to avoid erroring):
    -- animations.bbmodelname.animationname:setPlaying(state)
end

-- Action wheel
local mainPage = action_wheel:newPage()
action_wheel:setPage(mainPage)
-- Main Wheels
local outfitPage = action_wheel:newPage()
local skinPage = action_wheel:newPage()
-- Page 1
mainPage:newAction():title("Outfits"):item("minecraft:chainmail_chestplate"):onLeftClick(function(state, self)
    action_wheel:setPage(outfitPage)
end)
outfitPage:newAction():title("Go back"):item("minecraft:barrier"):onLeftClick(function(state, self)
    action_wheel:setPage(mainPage)
end)
-- Outfit Winter
function pings.toggleWinterOutfit(state)
    winterOutfit1:setVisible(state)
    winterOutfit2:setVisible(state)
    winterOutfit3:setVisible(state)
    winterOutfit4:setVisible(state)
    winterOutfit5:setVisible(state)
    winterOutfit6:setVisible(state)
    winterOutfit7:setVisible(state)
end

winterOutfit1 = models.chillet.root.main.torso4.torso3.Arms.LeftArm.winterOutfitLeftArm
winterOutfit2 = models.chillet.root.main.torso4.torso3.Arms.RightArm.winterOutfitRightArm
winterOutfit3 = models.chillet.root.main.torso4.torso3.torso2.winterOutfitMain
winterOutfit4 = models.chillet.root.main.torso4.torso3.torso2.torso.Head.winterOutfitHead
winterOutfit5 = models.chillet.root.main.torso4.torso3.torso2.torso.Head.earLeft.winterOutfitEarLeft
winterOutfit6 = models.chillet.root.main.torso4.torso3.torso2.torso.Head.earRight.winterOutfitEarRight
winterOutfit7 = models.chillet.root.main.torso5.torso6.torso7.torso8.winterOutfitTail

local Dress = outfitPage:newAction()
    :title("Winter Outfit Disabled")
    :toggleTitle("Winter Outfit Enabled")
    :item("red_wool")
    :toggleItem("green_wool")
    :setOnToggle(pings.toggleWinterOutfit)

-- Page 2
mainPage:newAction():title("Skins"):item("minecraft:sweet_berries"):onLeftClick(function(state, self)
    action_wheel:setPage(skinPage)
end)
skinPage:newAction():title("Go back"):item("minecraft:barrier"):onLeftClick(function(state, self)
    action_wheel:setPage(mainPage)
end)

-- Ignis
function pings.actionIgnis()
    models.chillet:setPrimaryTexture("custom", textures["textures.chillet_ignis"])

    for _, part in ipairs({
        models.chillet.root.main.torso4.torso3.Arms.LeftArm.winterOutfitLeftArm,
        models.chillet.root.main.torso4.torso3.Arms.RightArm.winterOutfitRightArm,
        models.chillet.root.main.torso4.torso3.torso2.winterOutfitMain,
        models.chillet.root.main.torso4.torso3.torso2.torso.Head.winterOutfitHead,
        models.chillet.root.main.torso4.torso3.torso2.torso.Head.earLeft.winterOutfitEarLeft,
        models.chillet.root.main.torso4.torso3.torso2.torso.Head.earRight.winterOutfitEarRight,
        models.chillet.root.main.torso5.torso6.torso7.torso8.winterOutfitTail
    }) do
        part:setPrimaryTexture("custom", textures["textures.winteroutfit_ignis"])
    end
end

local action = skinPage:newAction()
    :title("Ignis")
    :item("minecraft:blaze_powder")
    :onLeftClick(pings.actionIgnis)

-- Chillet
function pings.actionChillet()
    models.chillet:setPrimaryTexture("custom", textures["textures.chillet"])

    for _, part in ipairs({
        models.chillet.root.main.torso4.torso3.Arms.LeftArm.winterOutfitLeftArm,
        models.chillet.root.main.torso4.torso3.Arms.RightArm.winterOutfitRightArm,
        models.chillet.root.main.torso4.torso3.torso2.winterOutfitMain,
        models.chillet.root.main.torso4.torso3.torso2.torso.Head.winterOutfitHead,
        models.chillet.root.main.torso4.torso3.torso2.torso.Head.earLeft.winterOutfitEarLeft,
        models.chillet.root.main.torso4.torso3.torso2.torso.Head.earRight.winterOutfitEarRight,
        models.chillet.root.main.torso5.torso6.torso7.torso8.winterOutfitTail
    }) do
        part:setPrimaryTexture("custom", textures["textures.winteroutfit"])
    end
end

local action = skinPage:newAction()
    :title("Chillet")
    :item("minecraft:ice")
    :onLeftClick(pings.actionChillet)
