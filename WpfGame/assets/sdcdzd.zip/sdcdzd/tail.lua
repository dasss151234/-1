--default config
local config = {
    base_rot = vec(16, 0, 0), -- default rotation for tail

    shape = {}, -- table containing more tables with vectors that give extra rotation to tail e.g. {[1] = {add = vec(4, 0, 0), mul = vec(0.5, 1, 1)}} it will multiply rotation of first tail part by vec(0.5, 1, 1) and then it will add 4 on x axis 

    shape_alt = {}, -- same as shape but will be applied when tail is facing up 
    use_alt_shape = false, -- when disabled tail will not use shape_alt

    sleep_pose = {}, -- table of vectors that have rotation that will be applied when player is sleeping
    sleep_random_side = true, -- if enabled tail will have 50% chance of making sleep_pose flipped into other direction

    swim_x_limit = 0, -- how far should tail move when swimming
    y_min = -11, -- how much tail should move up when falling
    y_max = 1, -- how much tail should move down when going up
    y_speed = 10, -- how fast should tail move up or down
    body_vel_limit = 7, -- max tail rotation when spinning (left or right)
    max_sit_rot = 15, -- max rotation when rotating left or right while sitting

    water_offset1 = vec(0, 0.7, 0), -- offset from player position for detecting if player is half under water
    water_offset2 = vec(0, 1.4, 0), -- offset from player position for detecting if player is fully under water

    wag_enabled = true, -- disable or enable tail wag
    wag_speed = 0.8, -- how fast tail should wag
    wag_distance = 12, -- how far it should wag
}

--variables
local lerp = math.lerp
local clamp = math.clamp

local time = 0
local tail = {rawConfig = config}
local parts = {}
local old_rot = {}
local rot = {}
local vel = vec(0, 0, 0)
local was_sleeping
local sleep_side = 1
local wagAnim = false

--pings
function pings.tail_wag(x)
    wagAnim = x
end

--keybind
local wagKey = keybinds:newKeybind("Wag with tail", "key.keyboard.0")

wagKey.press = function()
    if config.wag_enabled then
        pings.tail_wag(true)
    end
end
wagKey.release = function()
    if config.wag_enabled then
        pings.tail_wag(false)
    end
end

--player anim
local anims = {
    STANDING = function(player_vel, body_vel, base_rot, inWater)
        rot[1].x = rot[1].x * (1-clamp(player_vel.x * 0, -0.05, 1)) + clamp(player_vel.y * config.y_speed, config.y_min, config.y_max)
        rot[1].y = rot[1].y + clamp(body_vel * 0.2 * (1-math.min(player_vel.xz:length() * 20, 1)), -config.body_vel_limit, config.body_vel_limit) + clamp(player_vel.z * -25, -3, 3) + math.sin(time * 0.5) * clamp(player_vel.x * 2, 0, 1)
       
        if inWater == -1 then
            base_rot.x = -math.abs(base_rot.x)
        elseif inWater == 0 then
            base_rot.x = base_rot.x < 0 and base_rot.x or 0
        end
        return base_rot
    end,
    CROUCHING = "STANDING",
    SWIMMING = function(player_vel, body_vel, base_rot, inWater)
        if inWater == 1 then
            --crawling
            rot[1].x = rot[1].x + clamp(player_vel.x * 5, -2, 2)
            rot[1].y = rot[1].y + clamp(body_vel * 0.2 * (1-math.min(player_vel.xz:length() * 20, 1)), -config.body_vel_limit, config.body_vel_limit)
        else
            --swimming
            rot[1].x = rot[1].x * 0.8 + math.clamp(player_vel.x * 30, -config.swim_x_limit, config.swim_x_limit)
            rot[1].y = rot[1].y + math.clamp(body_vel * 0.2, -config.body_vel_limit, config.body_vel_limit)
            base_rot.x = rot[1].x
        end

        return base_rot
    end,
    FALL_FLYING = function(_, body_vel, base_rot)
        rot[1].y = rot[1].y + math.clamp(body_vel * -0.3, -config.body_vel_limit, config.body_vel_limit)

        return base_rot
    end,
    SPIN_ATTACK = function(_, _, base_rot)
        rot[1].y = rot[1].y * 0.5 + config.body_vel_limit

        return base_rot
    end,
    SLEEPING = function()
        if not was_sleeping and config.sleep_random_side then
            sleep_side = math.random(0, 1) * 2 - 1
        end
        for i, v in pairs(config.sleep_pose) do
            rot[i] = v * 1
            rot[i].y = rot[i].y * sleep_side
            rot[i].z = rot[i].z * sleep_side
        end
        return rot[1], true
    end,
    SIT = function(player_vel, body_vel, base_rot, inWater)
        if inWater == -1 then
            base_rot.x = -math.abs(base_rot.x)
            rot[1].y = rot[1].y * 0.8 + body_vel * 0.1
        else
            rot[1].y = clamp((rot[1].y + body_vel * 0.1) * (1-player_vel.x), -config.max_sit_rot, config.max_sit_rot)
            base_rot.x = 2
        end
        base_rot.y = rot[1].y
        return base_rot
    end
}

--functions
local function updateAllParts(_, ...)
    local tbl = {...}
    parts = {}
    rot = {}
    for i = 1, #tbl do
        local part = tbl[i]
        parts[i] = {part}
        local parts_tbl = parts[i]
        local part_name, part_id = part:getName():match("^(.-)([%d-]*)$")
        part_id = tonumber(part_id) or 1

        local id = 1
        while part do
            id = id + 1
            part_id = part_id + 1
            part = part[part_name..part_id]
            parts_tbl[id] = part
        end
    end
    for i = 1, #parts[1] do
        rot[i] = vec(0, 0, 0)
        old_rot[i] = rot[i]
    end

    return tail
end

--tick
function tail.tick(pos, player_anim, player_vel, body_vel)
    --update time
    time = time + 1

    --move rotation
    for i = #parts[1], 1, -1 do
        old_rot[i] = rot[i]
        if i ~= 1 then
            rot[i] = rot[i-1]
        end
    end

    --update rot
    rot[1] = rot[1] + vel

    --tail wag
    if wagAnim then
        rot[1].y = rot[1].y * 0.5 + math.sin(time * config.wag_speed) * config.wag_distance
    end

    --change physics behaviour based on animation
    local base_rot = config.base_rot * 1

    --in water
    local inWater = 1
    if #world.getBlockState(pos+config.water_offset1):getFluidTags() >= 1 then
        if #world.getBlockState(pos+config.water_offset2):getFluidTags() >= 1 then
            inWater = -1
        else
            inWater = 0
        end
    end

    --update rotation based on animation
    if anims[player_anim] then
        if type(anims[player_anim]) == "string" then
            base_rot, was_sleeping = anims[anims[player_anim]](player_vel, body_vel, base_rot, inWater)
        else
            base_rot, was_sleeping = anims[player_anim](player_vel, body_vel, base_rot, inWater)
        end
    else
        base_rot, was_sleeping = anims.STANDING(player_vel, body_vel, base_rot, inWater)
    end

    --update velocity
    vel = vel * 0.7 + (base_rot - rot[1]) * 0.1
end

--render
function tail.render(delta)
    local shape = config.shape
    local shape_alt = config.shape
    if config.use_alt_shape then
        shape_alt = config.shape_alt
    end

    for _, v in pairs(parts) do
        for i, v2 in pairs(v) do
            local part_rot = lerp(old_rot[i], rot[i], delta)
            if part_rot.x < 0 then
                if shape_alt[i] then
                    if shape_alt[i].mul then
                        part_rot = part_rot * shape_alt[i].mul
                    end
                    if shape_alt[i].add then
                        part_rot = part_rot + shape_alt[i].add
                    end
                end
            else
                if shape[i] then
                    if shape[i].mul then
                        part_rot = part_rot * shape[i].mul
                    end
                    if shape[i].add then
                        part_rot = part_rot + shape[i].add
                    end
                end
            end 
            v2:setRot(part_rot)
        end
    end
end

--metatable
setmetatable(tail, {
    __call = updateAllParts,
    __newindex = function(t, i, v)
        if i == "config" then
            for i2, v2 in pairs(v) do
                config[i2] = v2
            end
        else
            rawset(t, i, v)
        end
    end
})

--return
return tail