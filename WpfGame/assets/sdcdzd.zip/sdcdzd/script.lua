-- Auto generated script file --

--hide vanilla elytra model
vanilla_model.ELYTRA:setVisible(false)

local anims = require("JimmyAnims")
anims(animations.fieryhorns)

-- LONG TAIL SCRIPT
getVelocity = require "velocity"
tail = require "tail" (models.fieryhorns.Body2.Tail.tail6)
tail.config = {
    base_rot = vectors.vec3(16, 0, 0),
    shape = {
        [1] = {add = vec(-5, 0, 0)},
        [2] = {add = vec(-20, 0, 0)},
        [3] = {add = vec(-15, 0, 0)},
        [4] = {add = vec(-15, 0, 0)},
	[5] = { add = vec(-15, 0, 0) },
	[6] = { add = vec(-15, 0, 0) },
	[7] = { add = vec(-20, 0, 0) },
	[8] = { add = vec(-20, 0, 0) },
	[9] = { add = vec(-20, 0, 0) },
	[10] = { add = vec(-20, 0, 0) },
	[11] = { add = vec(-20, 0, 0) }
    },
    shape_alt = {
        [1] = {add = vec(0, 0, 0)},
        [2] = {add = vec(0, 0, 0)},
        [3] = {add = vec(0, 0, 0)},
        [4] = {add = vec(0, 0, 0)},
        [5] = {add = vec(0, 0, 0)},
        [6] = {add = vec(0, 0, 0)},
        [7] = {add = vec(0, 0, 0)},
        [8] = {add = vec(0, 0, 0)},
        [9] = {add = vec(0, 0, 0)},
        [10] = {add = vec(0, 0, 0)},
        [11] = {add = vec(0, 0, 0)}
    },
    use_alt_shape = true,
    sleep_pose = {
        vec(10, 80, 0),
        vec(20, 10, 0),
        vec(5, 5, 0),
        vec(5, 15, 0),
        vec(30, -10, 0),
        vec(-5, 0, 0),
    },
    sleep_random_side = true,
}

function events.tick()
    vel, body_vel, rot_vel, head_vel = getVelocity()
    tail.tick(player:getPos(), player:getVehicle() and "SIT" or player:getPose(), vel, body_vel)
end
function events.render(delta)
    tail.render(delta)
end