
log ("Не забывай, мироходец..")
-- Auto generated script file --

--hide vanilla model
vanilla_model.PLAYER:setVisible(false)

--hide vanilla armor model
vanilla_model.ARMOR:setVisible(false)

local mainPage = action_wheel:newPage()
action_wheel:setPage(mainPage)


 function pings.Animation1()
   animations.model.GlassUp:play()

end
 
function pings.Animation2()
   animations.model.RICHARDWTFMOMENT:play()
   sounds:playSound("richard", player:getPos(), 10)

end

function pings.Animation3()
   animations.model.afk11:play()
   sounds:playSound("afkanim", player:getPos(), 10)
end

function pings.Animation4()

   animations.model.lovely:play()
   sounds:playSound("lovely", player:getPos(), 10)
end

function pings.StopAnimation()
   animations:stopAll()
end

function pings.toggle_outfit(state)
	config:save("outfit", state or nil)
	outfit = state
	
	models.model:setPrimaryTexture("Custom", state and textures["model.jdh-texture"] or textures["model.Lololowka1"])
end

local toggle_outfit = mainPage:newAction()
	:setTexture(textures["model.jdh-ico"])
	:setToggleTexture(textures["model.jdh-ico"])
	:setToggleColor(0,0,0)
	:title("Switch JDH skin")
	:toggleTitle("Switch Lololowka Skin")
	:setOnToggle(pings.toggle_outfit)

local Animation1 = mainPage:newAction()
    :title("Glass Up!")
    :item("minecraft:glass")
    :hoverColor(1, 0, 1)
    -- Pass in the ping function itself into onLeftClick
    :onLeftClick(pings.Animation1)

local Animation2 = mainPage:newAction()
    :title("RICHARD WTF MOMENT")
    :item("minecraft:string")
    :hoverColor(1, 0, 1)
    -- Pass in the ping function itself into onLeftClick
    :onLeftClick(pings.Animation2)

local Animation3 = mainPage:newAction()
    :title("Clean dust")
    :item("minecraft:gunpowder")
    :hoverColor(1, 0, 1)
    -- Pass in the ping function itself into onLeftClick
    :onLeftClick(pings.Animation3)

local StopAnimation = mainPage:newAction()
    :title("Stop Anim")
    :item("minecraft:barrier")
    :hoverColor(1, 0, 1)
    -- Pass in the ping function itself into onLeftClick
    :onLeftClick(pings.StopAnimation, Animation1:setToggled())

local Animation4 = mainPage:newAction()
    :title("likely")
    :item("minecraft:apple")
    :hoverColor(1, 0, 1)
    -- Pass in the ping function itself into onLeftClick
    :onLeftClick(pings.Animation4)











