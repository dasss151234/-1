--hide vanilla model
vanilla_model.PLAYER:setVisible(false)

--hide vanilla armor model
vanilla_model.ARMOR:setVisible(false)
vanilla_model.HELMET:setVisible(true)
models.model.root.Neck._Head.HelmetPivot:setScale(0.4, 0.4, 0.5)

--hide vanilla cape model
vanilla_model.CAPE:setVisible(false)

--hide vanilla elytra model
vanilla_model.ELYTRA:setVisible(false)

renderer:setShadowRadius(0.25)
--renderer:setCameraPos(0, -1, 0)

--entity init event, used for when the avatar entity is loaded for the first time
function events.entity_init()
  --player functions goes here
end

local bubble_time = 0

function pings.bubbleEmote()
    bubble_time = 160
end
local emotes_page = action_wheel:newPage("Emotes")
local emote_bubble = emotes_page:newAction()
  :title("Gush Entrails")
  :item("minecraft:cobweb")
  :onLeftClick(pings.bubbleEmote)
action_wheel:setPage(emotes_page)

--tick event, called 20 times per second
function events.tick()
  --code goes here
    local crouching = player:getPose() == "CROUCHING"
    local walking = player:getVelocity().xz:length() > .01
    local sprinting = player:isSprinting()
    local grounded = player:isOnGround()
    --animations.example.idle:setPlaying(not walking and not crouching)
    animations.model.walking:setPlaying(walking and not crouching and not sprinting and grounded)
    animations.model.running:setPlaying(sprinting and not crouching and grounded)
    animations.model.sneaking:setPlaying(crouching and grounded)

    local vertical_vel = player:getVelocity().y
    animations.model.jumping:setPlaying(vertical_vel > 1)
    animations.model.jumping:setBlend(math.min(vertical_vel * 2, 1))
    animations.model.falling:setPlaying(vertical_vel < 1)
    animations.model.falling:setBlend(math.min(-vertical_vel * 2, 1))

  if player:isVisuallySwimming() or player:isGliding() then
    models.model.root:setOffsetRot(-90)
  else
    models.model.root:setOffsetRot(0)
  end

  if bubble_time > 0 then
    for i=1, 20 do
      local particle_pos = vec(0, 0.5, 0)
      local particle_vel = vec(player:getVelocity().x, 0, player:getVelocity().z)
      particles:newParticle("minecraft:snowflake", particle_pos + player:getPos(), particle_vel)
    end
    if bubble_time % 2 == 0 then
      sounds:playSound("minecraft:entity.breeze.inhale", player:getPos(), 0.5, 2)
    end
      bubble_time = bubble_time - 1
  end
end

--render event, called every time your avatar is rendered
--it have two arguments, "delta" and "context"
--"delta" is the percentage between the last and the next tick (as a decimal value, 0.0 to 1.0)
--"context" is a string that tells from where this render event was called (the paperdoll, gui, player render, first person)
function events.render(delta, context)
  --code goes here
end
