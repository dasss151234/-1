-- Auto generated script file --

--hide vanilla armor model
vanilla_model.ARMOR:setVisible(false)

--hide vanilla cape model
vanilla_model.CAPE:setVisible(false)

--hide vanilla elytra model
vanilla_model.ELYTRA:setVisible(false)

--hide vanilla player model
vanilla_model.PLAYER:setVisible(false)

local CamPivot = require("GSCameraPivot")

local my_pivot = CamPivot.newCamera(
  models.SPDR.RootRoot.Root.Head.eye,
  vec(0, 1.75, 2.5),
  true, -- Set to `true` to forbid rolling the camera.
  true  -- Set to `true` to hide the part you entered above while in first person. (Used for FPM mods.)
       -- Set to a different model part to hide that model part instead.
)

CamPivot.setActiveCamera(my_pivot)