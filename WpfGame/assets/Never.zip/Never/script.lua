vanilla_model.PLAYER:setVisible(false)
vanilla_model.ARMOR:setVisible(false)
vanilla_model.ELYTRA:setVisible(false)

animations.never.idlep:play()

-- animations
local anims = require("JimmyAnims")
anims(animations.never)

animations.never.idlep:setBlendTime(2)
animations.never.fall:setBlendTime(2)
animations.never.spyglassR:setBlendTime(2)
animations.never.spyglassL:setBlendTime(2)

animations.never.fall:setSpeed(1.5)

-- physics
local SwingingPhysics = require("swinging_physics")
local swingOnBody = SwingingPhysics.swingOnBody

swingOnBody(models.never.root.Body.upper.cape.lower6, 0, {-35,0,0,0,0,0})

-- crosshair setings
local pos = vectors.vec3()

local function validBlock(block)
	return block and not block:isAir()
end
function events.ENTITY_INIT() pos:set(player:getPos()) end

function events.RENDER(delta, context)
	if context == "FIRST_PERSON" then
		local entity, entityPos = player:getTargetedEntity(host:getReachDistance())
		local block, blockPos = player:getTargetedBlock(true, host:getReachDistance())
		local deltaDeltaPos = player:getPos(delta) - player:getPos()
		pos:set(entity and entityPos:add(deltaDeltaPos) or
			validBlock(block) and blockPos:add(deltaDeltaPos) or
			player:getPos(delta):add(0, player:getEyeHeight())
				:add(player:getLookDir() * host:getReachDistance())
				:add(renderer:getEyeOffset())
		)
		
		local screenSpace = vectors.worldToScreenSpace(pos)
		local coords = screenSpace.xy:add(0, 0):mul(client:getScaledWindowSize()):div(2, 2)
		
		renderer:crosshairOffset(coords)
	end
end

renderer:setOffsetCameraPivot(0,0.8,0)

-- action wheel
local mainPage = action_wheel:newPage()
action_wheel:setPage(mainPage)

function pings.camera()
	renderer:setOffsetCameraPivot(0,0.8,0)
end

local action = mainPage:newAction()
    :title("Опустить камеру")
    :toggleTitle("Поднять камеру")
    :item("minecraft:golden_apple")
    :toggleItem("minecraft:enchanted_golden_apple")
    :setColor(vectors.hexToRGB("211f24"))
    :hoverColor(vectors.hexToRGB("544c63"))
	:toggleColor(vectors.hexToRGB("544c63"))
    :onToggle(function(isToggled)
        if isToggled then
            isHardlyActive = not isHardlyActive
            if isHardlyActive then
                renderer:setOffsetCameraPivot(0,0,0)
            else
                renderer:setOffsetCameraPivot(0,0,0)
            end
        else
            isHardlyActive = not isHardlyActive
        end
    end)
    :onLeftClick(pings.camera)
